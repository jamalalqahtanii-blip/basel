
// @ts-nocheck
import locale_C_58_C_58_Users_user_Desktop__1605_1588_1575_1585_1610_1593_32_1575_1587_1578_1579_1605_1575_1585_1603_1608_1605_Matgr_aswar_frontend_locales_ar_json from "../locales/ar.json";
import locale_C_58_C_58_Users_user_Desktop__1605_1588_1575_1585_1610_1593_32_1575_1587_1578_1579_1605_1575_1585_1603_1608_1605_Matgr_aswar_frontend_locales_en_json from "../locales/en.json";


export const localeCodes =  [
  "ar",
  "en"
]

export const localeLoaders = {
  "ar": [{ key: "../locales/ar.json", load: () => Promise.resolve(locale_C_58_C_58_Users_user_Desktop__1605_1588_1575_1585_1610_1593_32_1575_1587_1578_1579_1605_1575_1585_1603_1608_1605_Matgr_aswar_frontend_locales_ar_json), cache: true }],
  "en": [{ key: "../locales/en.json", load: () => Promise.resolve(locale_C_58_C_58_Users_user_Desktop__1605_1588_1575_1585_1610_1593_32_1575_1587_1578_1579_1605_1575_1585_1603_1608_1605_Matgr_aswar_frontend_locales_en_json), cache: true }]
}

export const vueI18nConfigs = [
  () => import("../i18n.config.ts?hash=bffaebcb&config=1" /* webpackChunkName: "__i18n_config_ts_bffaebcb" */)
]

export const nuxtI18nOptions = {
  "experimental": {
    "localeDetector": "",
    "switchLocalePathLinkSSR": false,
    "autoImportTranslationFunctions": false
  },
  "bundle": {
    "compositionOnly": true,
    "runtimeOnly": false,
    "fullInstall": true,
    "dropMessageCompiler": false
  },
  "compilation": {
    "jit": true,
    "strictMessage": true,
    "escapeHtml": false
  },
  "customBlocks": {
    "defaultSFCLang": "json",
    "globalSFCScope": false
  },
  "vueI18n": "./i18n.config.ts",
  "locales": [
    {
      "code": "ar",
      "language": "ar",
      "name": "العربية",
      "dir": "rtl",
      "files": [
        "C:/Users/user/Desktop/مشاريع استثماركوم/Matgr_aswar/frontend/locales/ar.json"
      ]
    },
    {
      "code": "en",
      "language": "en",
      "name": "English",
      "dir": "ltr",
      "files": [
        "C:/Users/user/Desktop/مشاريع استثماركوم/Matgr_aswar/frontend/locales/en.json"
      ]
    }
  ],
  "defaultLocale": "ar",
  "defaultDirection": "ltr",
  "routesNameSeparator": "___",
  "trailingSlash": false,
  "defaultLocaleRouteNameSuffix": "default",
  "strategy": "prefix_except_default",
  "lazy": false,
  "langDir": "locales",
  "detectBrowserLanguage": false,
  "differentDomains": false,
  "baseUrl": "",
  "dynamicRouteParams": false,
  "customRoutes": "page",
  "pages": {},
  "skipSettingLocaleOnNavigate": false,
  "types": "composition",
  "debug": false,
  "parallelPlugin": false,
  "multiDomainLocales": false,
  "i18nModules": []
}

export const normalizedLocales = [
  {
    "code": "ar",
    "language": "ar",
    "name": "العربية",
    "dir": "rtl",
    "files": [
      {
        "path": "C:/Users/user/Desktop/مشاريع استثماركوم/Matgr_aswar/frontend/locales/ar.json"
      }
    ]
  },
  {
    "code": "en",
    "language": "en",
    "name": "English",
    "dir": "ltr",
    "files": [
      {
        "path": "C:/Users/user/Desktop/مشاريع استثماركوم/Matgr_aswar/frontend/locales/en.json"
      }
    ]
  }
]

export const NUXT_I18N_MODULE_ID = "@nuxtjs/i18n"
export const parallelPlugin = false
export const isSSG = false

export const DEFAULT_DYNAMIC_PARAMS_KEY = "nuxtI18n"
export const DEFAULT_COOKIE_KEY = "i18n_redirected"
export const SWITCH_LOCALE_PATH_LINK_IDENTIFIER = "nuxt-i18n-slp"
