<script setup lang="ts">
import { ref, computed, watch } from 'vue'
import { useRouter } from 'vue-router'
import { useI18n } from 'vue-i18n'
// Nuxt i18n composable to build locale-switching links
// eslint-disable-next-line @typescript-eslint/ban-ts-comment
// @ts-ignore
import { useSwitchLocalePath } from '#i18n'
import { useWishlist } from '../composables/useWishlist'
import CategoriesSidebar from './CategoriesSidebar.vue'

const router = useRouter()
const { $get, $post } = useApi()
const auth = useAuth()
const cart = useCart()
const wishlist = useWishlist()
const { t, locale: i18nLocale } = useI18n()
const switchLocalePath = useSwitchLocalePath()

const uiDir = computed(() => ((i18nLocale as any).value === 'ar' ? 'rtl' : 'ltr'))
const isAr = computed(() => (i18nLocale as any).value === 'ar')
const currentLangCode = computed(() => (isAr.value ? 'AR' : 'EN'))

// Cart count
const cartCount = computed(() => {
  const items = cart.items.value || []
  return items.reduce((total: number, item: any) => {
    return total + Number(item?.quantity || item?.qty || 0)
  }, 0)
})

// Wishlist count
const wishlistCount = computed(() => {
  return wishlist.wishlistCount.value
})

// Comparison count
const compareCount = computed(() => {
  // For now, return 0. This should be connected to comparison state management
  // You can integrate with your comparison store/composable here
  return 0
})

// Load cart and wishlist on mount
onMounted(async () => {
  try {
    await cart.list()
  } catch (e) {
    console.warn('Failed to load cart in header:', e)
  }
  
  // Load wishlist if user is authenticated
  if (auth.user.value) {
    try {
      await wishlist.list()
    } catch (e) {
      console.warn('Failed to load wishlist in header:', e)
    }
  }
})

// Watch for auth changes to load wishlist
watch(() => auth.user.value, async (newUser) => {
  if (newUser) {
    try {
      await wishlist.list()
    } catch (e) {
      console.warn('Failed to load wishlist after login:', e)
    }
  } else {
    // Clear wishlist when user logs out
    // Clear wishlist when user logs out
    // wishlist.wishlist.value = []
  }
}, { immediate: false })

// Config
const { data: cfg } = await useAsyncData<any>('cfg-header', async () => {
  try {
    return await $get('v1/config')
  } catch (e) {
    return { name: '6valley' }
  }
})

const brandName = computed(() => {
  const v = cfg?.value as any
  return v?.company_name || v?.value?.name || v?.name || '6valley'
})

// Categories (fallback if API not ready)
type Cat = { id: number | string; name: string; children?: Cat[] }
const fallbackCats: Cat[] = [
  { id: 1, name: 'مكياج', children: [
    { id: '1-1', name: 'الوجه' },
    { id: '1-2', name: 'العيون' },
    { id: '1-3', name: 'الشفاه' },
  ]},
  { id: 2, name: 'العناية', children: [
    { id: '2-1', name: 'البشرة' },
    { id: '2-2', name: 'الشعر' },
  ]},
  { id: 3, name: 'العطور' },
]

const { data: catRes } = await useAsyncData<any>('header-cats', async () => {
  try {
    // Try a few common shapes
    const r = await $get('v1/categories')
    return r
  } catch (e) {
    return null
  }
})

function normalizeCat(item: any): Cat {
  const childrenSrc = Array.isArray(item?.children)
    ? item.children
    : Array.isArray(item?.childes)
      ? item.childes
      : []
  return {
    id: item?.id ?? item?.category_id ?? String(Math.random()),
    name: item?.name || item?.translation?.name || item?.title || '',
    children: childrenSrc.map((sc: any) => normalizeCat(sc)),
  }
}

const categories = computed<Cat[]>(() => {
  const raw = catRes?.value
  if (!raw) return fallbackCats
  if (Array.isArray(raw)) return raw.map(normalizeCat)
  if (Array.isArray(raw?.data)) return raw.data.map(normalizeCat)
  if (Array.isArray(raw?.categories)) return raw.categories.map(normalizeCat)
  return fallbackCats
})

// Get first 5 main categories for navigation
const mainCategories = computed<Cat[]>(() => {
  const cats = categories.value
  // If we have categories from API, take first 5
  if (cats.length > 0) {
    return cats.slice(0, 5)
  }
  // Fallback to predefined categories
  return fallbackCats.slice(0, 5)
})

// UI State
const showCats = ref(false)
const searchOpen = ref(false)
const q = ref('')
const loadingSearch = ref(false)
const suggestions = ref<string[]>([])
const products = ref<any[]>([])
const showLang = ref(false)
const loginModalOpen = useState('loginModalOpen', () => false)
const hoveredCategory = ref<any>(null)
const hoveredMegaCategory = ref<any>(null)
const keepMegaMenuOpen = ref(false)
const mobileMenuOpen = ref(false)
// Keep a lightweight dictionary for suggestions/typo-fix
const recentNames = ref<string[]>([])

// Global loading state
const globalLoading = ref(false)
const loadingProgress = ref(0)
const loadingMessage = ref('')

// Current route for active navigation
const route = useRoute()

// Watch for route changes and update locale accordingly
watch(() => route.path, (newPath) => {
  if (newPath.startsWith('/en/')) {
    if (i18nLocale.value !== 'en') {
      i18nLocale.value = 'en'
    }
  } else {
    if (i18nLocale.value !== 'ar') {
      i18nLocale.value = 'ar'
    }
  }
}, { immediate: true })

// Helper function to get localized path
const getLocalizedPath = (path: string) => {
  if (i18nLocale.value === 'en') {
    return path.startsWith('/en') ? path : '/en' + path
  } else {
    return path.startsWith('/en') ? path.substring(3) : path
  }
}

// Check if nav link is active
const isNavLinkActive = (path: string, exact = false) => {
  if (exact) {
    return route.path === path
  }
  return route.path.startsWith(path)
}

// Handle navigation click with loading
const handleNavClick = (pageName: string) => {
  // Start global loading
  const progressInterval = startGlobalLoading(`جاري تحميل ${pageName}...`)
  
  // Complete loading after a short delay
  setTimeout(() => {
    completeGlobalLoading(progressInterval)
  }, 800)
}

// Handle product click with loading
const handleProductClick = () => {
  // Start global loading
  const progressInterval = startGlobalLoading('جاري تحميل المنتج...')
  
  // Close search overlay
  searchOpen.value = false
  
  // Complete loading after a short delay
  setTimeout(() => {
    completeGlobalLoading(progressInterval)
  }, 600)
}

// Global loading functions
const startGlobalLoading = (message = 'جاري التحميل...') => {
  globalLoading.value = true
  loadingProgress.value = 0
  loadingMessage.value = message
  
  // Simulate progress
  const progressInterval = setInterval(() => {
    if (loadingProgress.value < 90) {
      loadingProgress.value += Math.random() * 30
    }
  }, 200)
  
  return progressInterval
}

const completeGlobalLoading = (progressInterval?: any) => {
  if (progressInterval) {
    clearInterval(progressInterval)
  }
  loadingProgress.value = 100
  setTimeout(() => {
    globalLoading.value = false
    loadingProgress.value = 0
    loadingMessage.value = ''
  }, 500)
}

// Login form state
const loginForm = ref({
  email: '',
  password: ''
})
const loginLoading = ref(false)
const loginError = ref('')
const loginSuccess = ref(false)
const logoutSuccess = ref(false)

// Register modal state
const showRegisterModal = ref(false)
const registerForm = ref({
  f_name: '',
  l_name: '',
  email: '',
  phone: '',
  password: '',
  password_confirmation: '',
  referral_code: ''
})
const registerLoading = ref(false)
const registerError = ref('')
const registerSuccess = ref(false)

// Build a dictionary from categories + popular chips + recent product names
const dictionary = computed<string[]>(() => {
  const set = new Set<string>()
  try {
    categories.value.forEach(c => {
      if (c?.name) set.add(String(c.name))
      ;(c.children || []).forEach(sc => { if (sc?.name) set.add(String(sc.name)) })
    })
  } catch {}
  popularChips.forEach(w => set.add(w))
  recentNames.value.forEach(w => set.add(w))
  return Array.from(set).filter(Boolean)
})

// Arabic-aware normalization to improve fuzzy matching
function normalizeArabic(input: string): string {
  return (input || '')
    .toLowerCase()
    .replace(/[\u064B-\u0652]/g, '') // remove diacritics
    .replace(/\u0640/g, '') // tatweel
    .replace(/[إأآا]/g, 'ا')
    .replace(/ة/g, 'ه')
    .replace(/ى/g, 'ي')
    .trim()
}

// Simple Levenshtein distance for typo tolerance
function lev(a: string, b: string): number {
  a = normalizeArabic(a)
  b = normalizeArabic(b)
  const m = a.length, n = b.length
  if (m === 0) return n
  if (n === 0) return m
  const dp = Array.from({ length: m + 1 }, () => new Array<number>(n + 1).fill(0))
  for (let i = 0; i <= m; i++) dp[i][0] = i
  for (let j = 0; j <= n; j++) dp[0][j] = j
  for (let i = 1; i <= m; i++) {
    for (let j = 1; j <= n; j++) {
      const cost = a[i - 1] === b[j - 1] ? 0 : 1
      dp[i][j] = Math.min(
        dp[i - 1][j] + 1,      // deletion
        dp[i][j - 1] + 1,      // insertion
        dp[i - 1][j - 1] + cost // substitution
      )
    }
  }
  return dp[m][n]
}

function getCorrections(term: string, max = 5): string[] {
  const q = normalizeArabic(term)
  if (!q) return []
  const pool = dictionary.value
  // Prefer contains matches first
  const containsMatches = pool.filter(w => normalizeArabic(w).includes(q))
  if (containsMatches.length) {
    // Sort by shortest and then lexicographically
    return containsMatches.sort((a,b)=>a.length - b.length || a.localeCompare(b)).slice(0, max)
  }
  // Fallback to Levenshtein distance
  const scored = pool.map(w => ({ w, d: lev(q, w) }))
  scored.sort((a,b)=> a.d - b.d || a.w.length - b.w.length)
  // Dynamic threshold: half the length (rounded up), min 1, max 4
  const threshold = Math.max(1, Math.min(4, Math.ceil(q.length / 2)))
  return scored.filter(s => s.d <= threshold).slice(0, max).map(s => s.w)
}

const popularChips = [
  'كريم اساس','كونسيلر','ريفلون','ماسكارا','برونزر','رموش','غسول','مرطب','سيروم','فيتامينات البشرة','العناية بالشعر'
]
const brandLogos = [
  'https://dummyimage.com/140x80/fff/333&text=TOPFACE',
  'https://dummyimage.com/140x80/fff/333&text=MAYBELLINE',
  'https://dummyimage.com/140x80/fff/333&text=NARS',
  'https://dummyimage.com/140x80/fff/333&text=ESSENCE',
]

async function fetchSearch(term: string) {
  if (!term || term.trim().length < 2) {
    suggestions.value = []
    products.value = []
    return
  }
  loadingSearch.value = true
  try {
    // Try common search endpoint shape; swallow errors gracefully
    console.log('[header] Searching for:', term)
    const r: any = await $get(`v1/products/search`, { params: { name: term, limit: 20 } })
    console.log('[header] Search response:', r)
    const rawList = Array.isArray(r?.products)
      ? r.products
      : Array.isArray(r?.data)
        ? r.data
        : Array.isArray(r?.products?.data)
          ? r.products.data
          : (Array.isArray(r) ? r : [])
    console.log('[header] Raw list:', rawList)
    // Normalize product fields used in UI
    const list = rawList.map((p: any) => ({
      ...p,
      name: p?.name || p?.product_name || p?.title || '',
      slug: p?.slug || p?.id,
      image_full_url: p?.image_full_url || p?.thumbnail || p?.image || p?.image_url,
      price: p?.price || p?.unit_price || p?.current_price || p?.selling_price,
    }))
    // Collect names for future suggestions
    recentNames.value = [
      ...new Set([
        ...recentNames.value,
        ...list.map((p: any) => String(p?.name || p?.product_name || '')).filter(Boolean)
      ])
    ]
    // Build suggestions: corrections + original term
    const corrections = getCorrections(term, 7)
    suggestions.value = Array.from(new Set([term, ...corrections]))
    products.value = list.slice(0, 20)
    console.log('[header] Final products count:', products.value.length)
  } catch (e) {
    console.error('[header] Search failed:', e)
    // Try fallback search
    try {
      const r: any = await $get(`v1/products`, { params: { search: term, limit: 20 } })
      const rawList = Array.isArray(r?.products)
        ? r.products
        : Array.isArray(r?.data)
          ? r.data
          : Array.isArray(r?.products?.data)
            ? r.products.data
            : (Array.isArray(r) ? r : [])
      const list = rawList.map((p: any) => ({
        ...p,
        name: p?.name || p?.product_name || p?.title || '',
        slug: p?.slug || p?.id,
        image_full_url: p?.image_full_url || p?.thumbnail || p?.image || p?.image_url,
        price: p?.price || p?.unit_price || p?.current_price || p?.selling_price,
      }))
      products.value = list.slice(0, 20)
      console.log('[header] Fallback search products count:', products.value.length)
    } catch (fallbackError) {
      console.error('[header] Fallback search also failed:', fallbackError)
      products.value = []
    }
    const corrections = getCorrections(term, 7)
    suggestions.value = Array.from(new Set([term, ...corrections]))
  } finally {
    loadingSearch.value = false
  }
}

let timer: any
watch(q, (val) => {
  clearTimeout(timer)
  timer = setTimeout(() => fetchSearch(val), 250)
})

function goSearch(term?: string) {
  const query = (term ?? q.value).trim()
  if (!query) return
  searchOpen.value = false
  
  // Start global loading
  const progressInterval = startGlobalLoading('جاري البحث...')
  
  // If no current hits, try a best correction
  const [best] = getCorrections(query, 1)
  const finalQ = (products.value.length === 0 && best && best !== query) ? best : query
  
  router.push({ path: '/shop', query: { q: finalQ } })
  
  // Complete loading after navigation
  setTimeout(() => {
    completeGlobalLoading(progressInterval)
  }, 1000)
}

function goCategory(cat: Cat) {
  // Navigate to category page or shop with category filter
  if (cat.id) {
    // Start global loading
    const progressInterval = startGlobalLoading('جاري تحميل التصنيف...')
    
    // Use getLocalizedPath to maintain locale prefix
    const localizedPath = getLocalizedPath('/shop')
    router.push({ path: localizedPath, query: { category: String(cat.id) } })
    
    // Complete loading after navigation
    setTimeout(() => {
      completeGlobalLoading(progressInterval)
    }, 1000)
  }
  showCats.value = false
}

function handleMegaMenuLeave() {
  // Add a small delay to allow moving to subcategories
  setTimeout(() => {
    if (!keepMegaMenuOpen.value) {
      showCats.value = false
      hoveredMegaCategory.value = null
    }
  }, 150)
}

// Reset keepMegaMenuOpen when showCats changes
watch(showCats, (newValue) => {
  if (!newValue) {
    keepMegaMenuOpen.value = false
    hoveredMegaCategory.value = null
  }
})

function changeLocale(loc: 'ar' | 'en') {
  // Start global loading
  const progressInterval = startGlobalLoading('جاري تغيير اللغة...')
  
  // Set locale first - this is crucial
  i18nLocale.value = loc
  showLang.value = false
  
  // Get current path and add/remove locale prefix
  let currentPath = route.path
  if (loc === 'en') {
    // Add /en prefix if not already present
    if (!currentPath.startsWith('/en')) {
      currentPath = '/en' + currentPath
    }
  } else {
    // Remove /en prefix for Arabic
    if (currentPath.startsWith('/en')) {
      currentPath = currentPath.substring(3)
    }
  }
  
  // Navigate to the new path
  router.push(currentPath)
  
  // Complete loading after navigation
  setTimeout(() => {
    completeGlobalLoading(progressInterval)
  }, 1000)
}

function switchTo(loc: 'ar' | 'en') {
  // Set locale first
  i18nLocale.value = loc
  showLang.value = false
  
  // Get current path and add/remove locale prefix
  let currentPath = route.path
  if (loc === 'en') {
    // Add /en prefix if not already present
    if (!currentPath.startsWith('/en')) {
      currentPath = '/en' + currentPath
    }
  } else {
    // Remove /en prefix for Arabic
    if (currentPath.startsWith('/en')) {
      currentPath = currentPath.substring(3)
    }
  }
  
  // Navigate to the new path and reload
  window.location.href = currentPath
}

// Login functions
async function handleLogin() {
  if (!loginForm.value.email || !loginForm.value.password) {
    loginError.value = t('login.required_fields') || 'جميع الحقول مطلوبة'
    return
  }
  
  loginLoading.value = true
  loginError.value = ''
  
  // Start global loading
  const progressInterval = startGlobalLoading('جاري تسجيل الدخول...')
  
  try {
    const response = await $post('v1/auth/login', {
      email_or_phone: loginForm.value.email,
      password: loginForm.value.password,
      type: 'email'
    })
    
    // Handle different response formats
    if (response?.access_token) {
      auth.setToken(response.access_token)
      // Try to get user info
      try {
        const userInfo = await $get('v1/customer/info')
        if (userInfo) auth.setUser(userInfo)
      } catch (e) {
        // If user info fails, still set token
        auth.setUser(response.user || response.data)
      }
      loginModalOpen.value = false
      loginForm.value = { email: '', password: '' }
      // Show success message
      loginSuccess.value = true
      setTimeout(() => {
        loginSuccess.value = false
        // Refresh the page after showing success message
        window.location.reload()
      }, 2000)
    } else if (response?.token) {
      auth.setToken(response.token)
      auth.setUser(response.user || response.data)
      loginModalOpen.value = false
      loginForm.value = { email: '', password: '' }
      // Show success message
      loginSuccess.value = true
      setTimeout(() => {
        loginSuccess.value = false
        // Refresh the page after showing success message
        window.location.reload()
      }, 2000)
    }
  } catch (error: any) {
    console.error('Login error:', error)
    // Handle validation errors
    if (error?.data?.errors && Array.isArray(error.data.errors)) {
      const errorMessages = error.data.errors.map((err: any) => err.message).join(', ')
      loginError.value = errorMessages
    } else {
      loginError.value = error?.data?.message || t('login.error') || 'خطأ في تسجيل الدخول'
    }
  } finally {
    loginLoading.value = false
    completeGlobalLoading(progressInterval)
  }
}

function openLoginModal() {
  loginModalOpen.value = true
  loginError.value = ''
  loginSuccess.value = false
  loginForm.value = { email: '', password: '' }
}

function closeLoginModal() {
  loginModalOpen.value = false
  loginError.value = ''
  loginSuccess.value = false
  loginForm.value = { email: '', password: '' }
}

// Register functions
function openRegisterModal() {
  showRegisterModal.value = true
  loginModalOpen.value = false
  registerError.value = ''
  registerSuccess.value = false
  registerForm.value = {
    f_name: '',
    l_name: '',
    email: '',
    phone: '',
    password: '',
    password_confirmation: '',
    referral_code: ''
  }
}

function closeRegisterModal() {
  showRegisterModal.value = false
  registerError.value = ''
  registerSuccess.value = false
  registerForm.value = {
    f_name: '',
    l_name: '',
    email: '',
    phone: '',
    password: '',
    password_confirmation: '',
    referral_code: ''
  }
}

const handleLogout = () => {
  if (confirm(t('logout_confirm') || 'هل أنت متأكد من تسجيل الخروج؟')) {
    auth.setToken(null)
    auth.setUser(null)
    mobileMenuOpen.value = false
    
    // Show success message
    logoutSuccess.value = true
    setTimeout(() => {
      logoutSuccess.value = false
      // Refresh the page after showing success message
      window.location.reload()
    }, 2000)
  }
}

async function handleRegisterSubmit() {
  if (!registerForm.value.f_name || !registerForm.value.l_name || !registerForm.value.email || !registerForm.value.phone || !registerForm.value.password) {
    registerError.value = 'جميع الحقول مطلوبة'
    return
  }

  if (registerForm.value.password !== registerForm.value.password_confirmation) {
    registerError.value = 'كلمة المرور غير متطابقة'
    return
  }

  if (registerForm.value.password.length < 6) {
    registerError.value = 'كلمة المرور يجب أن تكون 6 أحرف على الأقل'
    return
  }

  registerLoading.value = true
  registerError.value = ''

  // Start global loading
  const progressInterval = startGlobalLoading('جاري إنشاء الحساب...')

  try {
    const response = await $post('v1/auth/register', {
      f_name: registerForm.value.f_name,
      l_name: registerForm.value.l_name,
      email: registerForm.value.email,
      phone: registerForm.value.phone,
      password: registerForm.value.password,
      referral_code: registerForm.value.referral_code || null
    })

    if (response?.token) {
      // Login successful
      auth.setToken(response.token)
      try {
        const userInfo = await $get('v1/customer/info')
        if (userInfo) {
          auth.setUser(userInfo)
        }
      } catch (e) {
        auth.setUser(response.user || response.data)
      }
      closeRegisterModal()
      // Show success message
      registerSuccess.value = true
      setTimeout(() => {
        registerSuccess.value = false
        // Refresh the page after showing success message
        window.location.reload()
      }, 2000)
    } else if (response?.temporary_token) {
      // Need verification
      registerError.value = 'تم إنشاء الحساب بنجاح. يرجى التحقق من بريدك الإلكتروني أو رقم الهاتف'
      setTimeout(() => {
        closeRegisterModal()
      }, 3000)
    }
  } catch (error: any) {
    console.error('Register error:', error)
    if (error?.data?.errors && Array.isArray(error.data.errors)) {
      const errorMessages = error.data.errors.map((err: any) => err.message).join(', ')
      registerError.value = errorMessages
    } else {
      registerError.value = error?.data?.message || 'خطأ في إنشاء الحساب'
    }
  } finally {
    registerLoading.value = false
    completeGlobalLoading(progressInterval)
  }
}
</script>

<template>
  <header class="app-header" :dir="uiDir">
    <!-- Main Header -->
    <!-- Categories Sidebar -->
    <CategoriesSidebar />


    <div class="main-header">
    <div class="container">
        <div class="row" style="width:100%;align-items: center;">
          <div class="col-3 col-md-1">
            <!-- Logo Section -->
            <div class="logo-section">
              <NuxtLink :to="getLocalizedPath('/')" class="brand">
                  <div class="logo-container">
                    <img src="/images/go-tawfeer-1-1.webp" alt="logo" class="logo-img">
                  </div>
                </NuxtLink>
            </div>
          </div>
          <div class="col-7 col-md-7">
            <!-- Search Section -->
            <div class="search-section">
              <div class="search-container" @click="searchOpen = true">
                <div class="search-box">
                  <svg width="30" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier"> <path d="M11 6C13.7614 6 16 8.23858 16 11M16.6588 16.6549L21 21M19 11C19 15.4183 15.4183 19 11 19C6.58172 19 3 15.4183 3 11C3 6.58172 6.58172 3 11 3C15.4183 3 19 6.58172 19 11Z" stroke="#111111" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path> </g></svg>
                      <input type="text" :placeholder="t('search.placeholder')" readonly class="search-input" />
                </div>
              </div>
            </div>
          </div>
          <div class="col-2 col-md-4">
                    <!-- Actions Section -->
            <div class="actions-section">
              <!-- Mobile Menu Button -->
              <button class="mobile-menu-btn" @click="mobileMenuOpen = !mobileMenuOpen">
                <svg width="20" height="20" viewBox="0 0 24 24">
                  <path fill="currentColor" d="M3 6h18v2H3V6m0 5h18v2H3v-2m0 5h18v2H3v-2Z"/>
                </svg>
              </button>
              <div class="row mobile-none" >
                <div class="col-6">
                  <div class="info-left" style="float: left;width: 90%;border-radius:25px;background: #F58040;">
                    <div class="row align-items-center">
                      <div class="col-4">
                        <svg class="bg-dark p-2 m-1" style="border-radius:50%" width="40" viewBox="0 0 18 18" xmlns="http://www.w3.org/2000/svg" fill="#000000"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier"> <path d="M16 7.184C16 3.14 12.86 0 9 0S2 3.14 2 7c-1.163.597-2 1.696-2 3v2a3 3 0 0 0 3 3h1a1 1 0 0 0 1-1V8a1 1 0 0 0-1-1 5 5 0 0 1 10 0 1 1 0 0 0-1 1v6a1 1 0 0 0 1 1v1h-2.592c-.206-.581-.756-1-1.408-1H8a1.5 1.5 0 0 0 0 3h6a2 2 0 0 0 2-2v-1.183A2.992 2.992 0 0 0 18 12v-2a2.99 2.99 0 0 0-2-2.816L-7 62" fill="#ffffff" fill-rule="evenodd"></path> </g></svg>
                      </div>
                      <div class="col-8">
                        <p style="font-size: 12px;"  class="mb-0 fw-bold text-white">{{ t('support_24_7') || 'دعم 24/7' }}
                          <br>
                          <span style="color: #232323">
                            966537030838
                          </span>
                          
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col-6">
                  <div class="info-left" style="float: left;width: 90%;border-radius:25px;background: #F58040;">
                    <div class="row align-items-center">
                      <div class="col-4">
                        <svg class="bg-dark p-2 m-1" style="border-radius:50%" fill="#ffffff" width="40" version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 512 512" xml:space="preserve" stroke="#ffffff"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier"> <g> <g> <path d="M476.158,231.363l-13.259-53.035c3.625-0.77,6.345-3.986,6.345-7.839v-8.551c0-18.566-15.105-33.67-33.67-33.67h-60.392 V110.63c0-9.136-7.432-16.568-16.568-16.568H50.772c-9.136,0-16.568,7.432-16.568,16.568V256c0,4.427,3.589,8.017,8.017,8.017 c4.427,0,8.017-3.589,8.017-8.017V110.63c0-0.294,0.239-0.534,0.534-0.534h307.841c0.295,0,0.534,0.241,0.534,0.534v145.372 c0,4.427,3.589,8.017,8.017,8.017c4.427,0,8.017-3.589,8.017-8.017v-9.088h94.569c0.008,0,0.014,0.002,0.021,0.002 c0.008,0,0.015-0.001,0.022-0.001c11.637,0.008,21.518,7.646,24.912,18.171h-24.928c-4.427,0-8.017,3.589-8.017,8.017v17.102 c0,13.851,11.268,25.119,25.119,25.119h9.086v35.273h-20.962c-6.886-19.884-25.787-34.205-47.982-34.205 s-41.097,14.321-47.982,34.205h-3.86v-60.393c0-4.427-3.589-8.017-8.017-8.017c-4.427,0-8.017,3.589-8.017,8.017v60.391H192.817 c-6.886-19.884-25.787-34.205-47.982-34.205s-41.097,14.321-47.982,34.205H50.772c-0.295,0-0.534-0.241-0.534-0.534v-17.637 h34.739c4.427,0,8.017-3.589,8.017-8.017s-3.589-8.017-8.017-8.017h-42.75c-0.002,0-0.003,0-0.005,0s-0.003,0-0.005,0H8.017 c-4.427,0-8.017,3.589-8.017,8.017s3.589,8.017,8.017,8.017h26.188v17.637c0,9.136,7.432,16.568,16.568,16.568h43.304 c-0.002,0.178-0.014,0.356-0.014,0.534c0,27.995,22.777,50.772,50.772,50.772s50.772-22.777,50.772-50.772 c0-0.178-0.012-0.356-0.014-0.534h180.67c-0.002,0.178-0.014,0.356-0.014,0.534c0,27.995,22.777,50.772,50.772,50.772 c27.995,0,50.772-22.777,50.772-50.772c0-0.178-0.012-0.356-0.014-0.534h26.203c4.427,0,8.017-3.589,8.017-8.017v-85.511 C512,251.989,496.423,234.448,476.158,231.363z M375.182,144.301h60.392c9.725,0,17.637,7.912,17.637,17.637v0.534h-78.029 V144.301z M375.182,230.881v-52.376h71.235l13.094,52.376H375.182z M144.835,401.904c-19.155,0-34.739-15.583-34.739-34.739 s15.584-34.739,34.739-34.739c19.155,0,34.739,15.583,34.739,34.739S163.99,401.904,144.835,401.904z M427.023,401.904 c-19.155,0-34.739-15.583-34.739-34.739s15.584-34.739,34.739-34.739c19.155,0,34.739,15.583,34.739,34.739 S446.178,401.904,427.023,401.904z M495.967,299.29h-9.086c-5.01,0-9.086-4.076-9.086-9.086v-9.086h18.171V299.29z"></path> </g> </g> <g> <g> <path d="M144.835,350.597c-9.136,0-16.568,7.432-16.568,16.568c0,9.136,7.432,16.568,16.568,16.568 c9.136,0,16.568-7.432,16.568-16.568C161.403,358.029,153.971,350.597,144.835,350.597z"></path> </g> </g> <g> <g> <path d="M427.023,350.597c-9.136,0-16.568,7.432-16.568,16.568c0,9.136,7.432,16.568,16.568,16.568 c9.136,0,16.568-7.432,16.568-16.568C443.591,358.029,436.159,350.597,427.023,350.597z"></path> </g> </g> <g> <g> <path d="M332.96,316.393H213.244c-4.427,0-8.017,3.589-8.017,8.017s3.589,8.017,8.017,8.017H332.96 c4.427,0,8.017-3.589,8.017-8.017S337.388,316.393,332.96,316.393z"></path> </g> </g> <g> <g> <path d="M127.733,282.188H25.119c-4.427,0-8.017,3.589-8.017,8.017s3.589,8.017,8.017,8.017h102.614 c4.427,0,8.017-3.589,8.017-8.017S132.16,282.188,127.733,282.188z"></path> </g> </g> <g> <g> <path d="M204.693,136.818c-42.141,0-76.426,34.285-76.426,76.426s34.285,76.426,76.426,76.426s76.426-34.285,76.426-76.426 S246.834,136.818,204.693,136.818z M204.693,273.637c-33.3,0-60.392-27.092-60.392-60.392s27.092-60.392,60.392-60.392 s60.392,27.092,60.392,60.392S237.993,273.637,204.693,273.637z"></path> </g> </g> <g> <g> <path d="M236.015,233.229l-23.305-23.305V179.04c0-4.427-3.589-8.017-8.017-8.017s-8.017,3.589-8.017,8.017v34.205 c0,2.126,0.844,4.164,2.348,5.668l25.653,25.653c1.565,1.565,3.617,2.348,5.668,2.348s4.104-0.782,5.668-2.348 C239.146,241.435,239.146,236.36,236.015,233.229z"></path> </g> </g> </g></svg>
                      </div>
                      <div class="col-8">
                        <p style="font-size: 12px;"  class="mb-0 fw-bold text-white">{{ t('free_shipping') || 'شحن مجاني' }}
                          <br>
                          <span style="color:#232323">
                            {{ t('purchases_over_299') || 'للمشتريات فوق 299' }}
                          </span>
                          <img src="../images/Vector (4).png" alt="">
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
             
              
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Navigation Bar -->
    <nav class="nav-bar">
      <div class="container">
        <div class="nav-left">
          <div class="categories-dropdown" @mouseenter="showCats = true" @mouseleave="showCats = false">
            <button class="categories-btn">
              <svg class="categories-icon" width="30" height="30" viewBox="0 0 24 24">
                <path fill="currentColor" d="M3 6h18v2H3V6m0 5h18v2H3v-2m0 5h18v2H3v-2Z"/>
              </svg>
              <span>{{ t('all_categories') || 'جميع الأقسام' }}</span>
              <svg width="12" height="12" viewBox="0 0 24 24" class="chevron">
                <path fill="currentColor" d="M7.41 8.59L12 13.17l4.59-4.58L18 10l-6 6-6-6 1.41-1.41z"/>
              </svg>
            </button>

            <div v-show="showCats" class="mega-menu" @mouseenter="showCats = true" @mouseleave="handleMegaMenuLeave">
              <div class="mega-content">
                <!-- Main Categories Column -->
                <div class="mega-main-categories">
                  <div 
                    v-for="c in categories" 
                    :key="c.id" 
                    class="mega-category-item"
                    @mouseenter="hoveredMegaCategory = c; keepMegaMenuOpen = true"
                    @mouseleave="keepMegaMenuOpen = false"
                  >
                    <div class="mega-title" @click="goCategory(c)">
                      {{ c.name }}
                      <svg v-if="c.children && c.children.length > 0" width="12" height="12" viewBox="0 0 24 24" class="mega-arrow">
                        <path fill="currentColor" d="M7.41 8.59L12 13.17l4.59-4.58L18 10l-6 6-6-6 1.41-1.41z"/>
                      </svg>
                    </div>
                  </div>
                </div>
                
                <!-- Subcategories Area -->
                <div class="mega-subcategories-area" @mouseenter="keepMegaMenuOpen = true" @mouseleave="keepMegaMenuOpen = false">
                  <div v-if="hoveredMegaCategory && hoveredMegaCategory.children && hoveredMegaCategory.children.length > 0" class="mega-subcategories">
                    <div class="mega-subcategories-content">
                      <div 
                        v-for="sc in hoveredMegaCategory.children" 
                        :key="sc.id" 
                        class="mega-subcategory-item"
                        @click="goCategory(sc)"
                      >
                        {{ sc.name }}
                      </div>
                    </div>
                  </div>
                  <div v-else class="mega-placeholder">
                    <img src="https://dummyimage.com/220x160/f5f5f5/888&text=Promo" alt="promo" />
                    <div class="brands">
                      <img v-for="(b,i) in brandLogos" :key="i" :src="b" alt="brand" />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div class="nav-center">
          <div class="nav-links">
            <!-- الرئيسية -->
            <div class="nav-item">
              <NuxtLink :to="getLocalizedPath('/')" :class="['nav-link', { active: isNavLinkActive('/', true) }]" @click="handleNavClick(t('home'))">
                <svg width="20" height="20" viewBox="0 0 24 24" class="nav-icon">
                  <path fill="currentColor" d="M10 20v-6h4v6h5v-8h3L12 3L2 12h3v8z"/>
                </svg>
                <span>{{ t('home') }}</span>
              </NuxtLink>
            </div>

            <!-- كل المنتجات -->
            <div class="nav-item">
              <NuxtLink :to="getLocalizedPath('/shop')" :class="['nav-link', { active: isNavLinkActive('/shop') }]" @click="handleNavClick(t('all_products'))">
                <svg width="20" height="20" viewBox="0 0 24 24" class="nav-icon">
                  <path fill="currentColor" d="M3 6h18v2H3V6m0 5h18v2H3v-2m0 5h18v2H3v-2Z"/>
                </svg>
                <span>{{ t('all_products') }}</span>
              </NuxtLink>
            </div>

            <!-- التصنيفات -->
            <div class="nav-item">
              <NuxtLink :to="getLocalizedPath('/categories')" :class="['nav-link', { active: isNavLinkActive('/categories') }]" @click="handleNavClick(t('categories'))">
                <svg width="20" height="20" viewBox="0 0 24 24" class="nav-icon">
                  <path fill="currentColor" d="M3 6h18v2H3V6m0 5h18v2H3v-2m0 5h18v2H3v-2Z"/>
                </svg>
                <span>{{ t('categories') }}</span>
              </NuxtLink>
            </div>

            <!-- وصل حديثا -->
            <div class="nav-item">
              <NuxtLink :to="getLocalizedPath('/shop?sort=newest')" :class="['nav-link', { active: route.query.sort === 'newest' }]" @click="handleNavClick(t('newest'))">
                <svg width="20" height="20" viewBox="0 0 24 24" class="nav-icon">
                  <rect x="2" y="3" width="20" height="14" rx="2" ry="2" fill="currentColor"/>
                  <text x="12" y="11" text-anchor="middle" fill="white" font-size="8" font-weight="bold">NEW</text>
                </svg>
                <span>{{ t('newest') }}</span>
              </NuxtLink>
            </div>

            <!-- الاعلى مبيعا -->
            <div class="nav-item">
              <NuxtLink :to="getLocalizedPath('/shop?sort=best_selling')" :class="['nav-link', { active: route.query.sort === 'best_selling' }]" @click="handleNavClick(t('best_selling'))">
                <svg width="20" height="20" viewBox="0 0 24 24" class="nav-icon">
                  <path fill="currentColor" d="M3 13h2v-2H3v2zm0 4h2v-2H3v2zm0-8h2V7H3v2zm4 4h14v-2H7v2zm0 4h14v-2H7v2zM7 7v2h14V7H7z"/>
                </svg>
                <span>{{ t('best_selling') }}</span>
              </NuxtLink>
            </div>

            <!-- عروض -->
            <div class="nav-item">
              <NuxtLink :to="getLocalizedPath('/shop?has_discount=true')" :class="['nav-link', { active: route.query.has_discount === 'true' }]" @click="handleNavClick(t('offers'))">
                <svg width="20" height="20" viewBox="0 0 24 24" class="nav-icon">
                  <path fill="currentColor" d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
                </svg>
                <span>{{ t('offers') }}</span>
              </NuxtLink>
            </div>

            <!-- براندات -->
            <div class="nav-item">
              <NuxtLink :to="getLocalizedPath('/brands')" :class="['nav-link', { active: isNavLinkActive('/brands') }]" @click="handleNavClick(t('brands'))">
                <svg width="20" height="20" viewBox="0 0 24 24" class="nav-icon">
                  <path fill="currentColor" d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
                </svg>
                <span>{{ t('brands') }}</span>
              </NuxtLink>
            </div>
          </div>
        </div>
        <div class="nav-right d-flex gap-2 align-items-center">
          
            <!-- Language Selector -->
            <div class="lang" @click="showLang = !showLang">
              <button class="lang-btn">
                <svg width="16" height="16" viewBox="0 0 24 24">
                  <path fill="currentColor" d="M12.87 15.07l-2.54-2.51.03-.03c1.74-1.94 2.98-4.17 3.71-6.53H17V4h-7V2H8v2H1v1.99h11.17C11.5 7.92 10.44 9.75 9 11.35 8.07 10.32 7.3 9.19 6.69 8h-2c.73 1.63 1.73 3.17 2.98 4.56l-5.09 5.02L4 19l5-5 3.11 3.11.76-2.04zM18.5 10h-2L12 22h2l1.12-3h4.75L21 22h2l-4.5-12zm-2.62 7l1.62-4.33L19.12 17h-3.24z"/>
                </svg>
                <span>{{ currentLangCode }}</span>
                <svg width="12" height="12" viewBox="0 0 24 24" class="chevron">
                  <path fill="currentColor" d="M7.41 8.59L12 13.17l4.59-4.58L18 10l-6 6-6-6 1.41-1.41z"/>
                </svg>
              </button>

              <div v-show="showLang" class="lang-menu">
                <div class="lang-title">{{ t('select_language') || 'اختر اللغة' }}</div>
                <div class="lang-grid">
                    <div class="lang-card" :class="{ checked: isAr }" @click="switchTo('ar')">
                    <div class="row">
                      <div class="col-6">
                        <div class="meta">
                            <span class="flag">🇸🇦</span>
                            <span class="label">العربية</span>
                        </div>
                      </div>
                      <div class="col-6">
                        <div class="radio" :class="{ checked: isAr }"></div>

                      </div>
                    </div>
                    </div>
                    <div class="lang-card" :class="{ checked: !isAr }" @click="switchTo('en')">
                      <div class="row">
                        <div class="col-6">
                          <div class="meta">
                              <span class="flag">🇺🇸</span>
                              <span class="label">English</span>
                          </div>
                        </div>
                        <div class="col-6">
                          <div class="radio" :class="{ checked: !isAr }"></div>
                        </div>
                      </div>
                    </div>
                </div>
              </div>
            </div>
            <div class="profile">
              <template v-if="auth?.user?.value">
                  <NuxtLink class="profile-btn" :to="getLocalizedPath('/account')">
                    <svg viewBox="0 0 20 20" width="25" xmlns="http://www.w3.org/2000/svg" fill="#000000"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier"> <path fill="#F58040" d="M9.99296258,10.5729355 C12.478244,10.5729355 14.4929626,8.55821687 14.4929626,6.0729355 C14.4929626,3.58765413 12.478244,1.5729355 9.99296258,1.5729355 C7.5076812,1.5729355 5.49296258,3.58765413 5.49296258,6.0729355 C5.49296258,8.55821687 7.5076812,10.5729355 9.99296258,10.5729355 Z M10,0 C13.3137085,0 16,2.6862915 16,6 C16,8.20431134 14.8113051,10.1309881 13.0399615,11.173984 C16.7275333,12.2833441 19.4976819,15.3924771 19.9947005,19.2523727 C20.0418583,19.6186047 19.7690435,19.9519836 19.3853517,19.9969955 C19.0016598,20.0420074 18.6523872,19.7816071 18.6052294,19.4153751 C18.0656064,15.2246108 14.4363723,12.0699838 10.034634,12.0699838 C5.6099956,12.0699838 1.93381693,15.231487 1.39476476,19.4154211 C1.34758036,19.7816499 0.998288773,20.0420271 0.614600177,19.9969899 C0.230911582,19.9519526 -0.0418789616,19.6185555 0.00530544566,19.2523267 C0.500630192,15.4077896 3.28612316,12.3043229 6.97954305,11.1838052 C5.19718955,10.1447285 4,8.21217353 4,6 C4,2.6862915 6.6862915,0 10,0 Z"></path> </g></svg>
                </NuxtLink>
              </template>
              <template v-else>
                  <button class="login-btn" @click="openLoginModal">
                      <svg viewBox="0 0 20 20" width="25" xmlns="http://www.w3.org/2000/svg" fill="#000000"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier"> <path fill="#F58040" d="M9.99296258,10.5729355 C12.478244,10.5729355 14.4929626,8.55821687 14.4929626,6.0729355 C14.4929626,3.58765413 12.478244,1.5729355 9.99296258,1.5729355 C7.5076812,1.5729355 5.49296258,3.58765413 5.49296258,6.0729355 C5.49296258,8.55821687 7.5076812,10.5729355 9.99296258,10.5729355 Z M10,0 C13.3137085,0 16,2.6862915 16,6 C16,8.20431134 14.8113051,10.1309881 13.0399615,11.173984 C16.7275333,12.2833441 19.4976819,15.3924771 19.9947005,19.2523727 C20.0418583,19.6186047 19.7690435,19.9519836 19.3853517,19.9969955 C19.0016598,20.0420074 18.6523872,19.7816071 18.6052294,19.4153751 C18.0656064,15.2246108 14.4363723,12.0699838 10.034634,12.0699838 C5.6099956,12.0699838 1.93381693,15.231487 1.39476476,19.4154211 C1.34758036,19.7816499 0.998288773,20.0420271 0.614600177,19.9969899 C0.230911582,19.9519526 -0.0418789616,19.6185555 0.00530544566,19.2523267 C0.500630192,15.4077896 3.28612316,12.3043229 6.97954305,11.1838052 C5.19718955,10.1447285 4,8.21217353 4,6 C4,2.6862915 6.6862915,0 10,0 Z"></path> </g></svg>
                  </button>
              </template>
            </div>
            
            <!-- Wishlist -->
            <NuxtLink :to="getLocalizedPath('/account?tab=wishlist')" class="action-btn wishlist-btn position-relative">
              <svg width="25" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M20.84 4.61C20.3292 4.099 19.7228 3.69364 19.0554 3.41708C18.3879 3.14052 17.6725 2.99817 16.95 2.99817C16.2275 2.99817 15.5121 3.14052 14.8446 3.41708C14.1772 3.69364 13.5708 4.099 13.06 4.61L12 5.67L10.94 4.61C9.9083 3.5783 8.50903 2.9987 7.05 2.9987C5.59096 2.9987 4.19169 3.5783 3.16 4.61C2.1283 5.6417 1.5487 7.04097 1.5487 8.5C1.5487 9.95903 2.1283 11.3583 3.16 12.39L12 21.23L20.84 12.39C21.351 11.8792 21.7563 11.2728 22.0329 10.6053C22.3095 9.93789 22.4518 9.22248 22.4518 8.5C22.4518 7.77752 22.3095 7.06211 22.0329 6.39467C21.7563 5.72723 21.351 5.1208 20.84 4.61Z" stroke="#F58040" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
              </svg>
              <span v-if="wishlistCount > 0" class="wishlist-badge badge bg-danger position-absolute top-0 start-100 translate-middle rounded-pill">{{ wishlistCount }}</span>
            </NuxtLink>
            
            <!-- Comparison -->
            <NuxtLink :to="getLocalizedPath('/compare')" class="action-btn compare-btn position-relative">
              <svg width="25" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier"> <path d="M18 8V15.3C18 16.4201 18 16.9802 17.782 17.408C17.5903 17.7843 17.2843 18.0903 16.908 18.282C16.4802 18.5 15.9201 18.5 14.8 18.5H12M18 8C19.3807 8 20.5 6.88071 20.5 5.5C20.5 4.11929 19.3807 3 18 3C16.6193 3 15.5 4.11929 15.5 5.5C15.5 6.88071 16.6193 8 18 8ZM12 18.5L14 16M12 18.5L14 21M6 16V8.7C6 7.5799 6 7.01984 6.21799 6.59202C6.40973 6.21569 6.71569 5.90973 7.09202 5.71799C7.51984 5.5 8.0799 5.5 9.2 5.5H12M6 16C4.61929 16 3.5 17.1193 3.5 18.5C3.5 19.8807 4.61929 21 6 21C7.38071 21 8.5 19.8807 8.5 18.5C8.5 17.1193 7.38071 16 6 16ZM12 5.5L10 8M12 5.5L10 3" stroke="#F58040" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path> </g></svg>
              <span v-if="compareCount > 0" class="compare-badge badge bg-danger position-absolute top-0 start-100 translate-middle rounded-pill">{{ compareCount }}</span>
            </NuxtLink>
            
            <!-- Cart -->
            <NuxtLink :to="getLocalizedPath('/cart')" class="action-btn cart-btn position-relative">
              <svg width="25" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier"> <path d="M20.2236 12.5257C19.6384 9.40452 19.3458 7.84393 18.2349 6.92196C17.124 6 15.5362 6 12.3606 6H11.6394C8.46386 6 6.87608 6 5.76518 6.92196C4.65428 7.84393 4.36167 9.40452 3.77645 12.5257C2.95353 16.9146 2.54207 19.1091 3.74169 20.5545C4.94131 22 7.17402 22 11.6394 22H12.3606C16.826 22 19.0587 22 20.2584 20.5545C20.9543 19.7159 21.108 18.6252 20.9537 17" stroke="#ffffff" stroke-width="1.5" stroke-linecap="round"></path> <path d="M9 6V5C9 3.34315 10.3431 2 12 2C13.6569 2 15 3.34315 15 5V6" stroke="#ffffff" stroke-width="1.5" stroke-linecap="round"></path> </g></svg>
              <span v-if="cartCount > 0" class="cart-badge badge bg-danger position-absolute top-0 start-100 translate-middle rounded-pill">{{ cartCount }}</span>
            </NuxtLink>
        </div>
      </div>
    </nav>

    <!-- Mobile Menu Overlay -->
    <teleport to="body">
      <div v-if="mobileMenuOpen" class="mobile-menu-overlay" @click.self="mobileMenuOpen = false">
        <div class="mobile-menu" :dir="uiDir">
          <div class="mobile-menu-header">
            <h3>{{ t('menu') || 'القائمة' }}</h3>
            <button class="close-btn" @click="mobileMenuOpen = false">
              <svg width="20" height="20" viewBox="0 0 24 24">
                <path fill="currentColor" d="M19 6.41L17.59 5L12 10.59L6.41 5L5 6.41L10.59 12L5 17.59L6.41 19L12 13.41L17.59 19L19 17.59L13.41 12z"/>
              </svg>
            </button>
          </div>
          
          <div class="mobile-menu-content">
            <!-- Categories -->
            <div class="mobile-menu-section">
              <h4>{{ t('all_categories') || 'جميع الأقسام' }}</h4>
              <div class="mobile-menu-links">
                <NuxtLink 
                  v-for="category in mainCategories" 
                  :key="category.id"
                  :to="`/category/${category.id}`" 
                  class="mobile-menu-link"
                  @click="mobileMenuOpen = false"
                >
                  {{ category.name }}
                </NuxtLink>
              </div>
            </div>
            
            <!-- Quick Links -->
            <div class="mobile-menu-section">
              <h4>{{ t('quick_links') || 'روابط سريعة' }}</h4>
              <div class="mobile-menu-links">
                <NuxtLink :to="getLocalizedPath('/shop')" class="mobile-menu-link" @click="mobileMenuOpen = false">
                  {{ t('shop') || 'المتجر' }}
                </NuxtLink>
                <NuxtLink :to="getLocalizedPath('/brands')" class="mobile-menu-link" @click="mobileMenuOpen = false">
                  {{ t('brands') || 'العلامات التجارية' }}
                </NuxtLink>
                <NuxtLink :to="getLocalizedPath('/shop?has_discount=true')" class="mobile-menu-link" @click="mobileMenuOpen = false">
                  {{ t('offers') || 'العروض' }}
                </NuxtLink>
                <NuxtLink :to="getLocalizedPath('/contact')" class="mobile-menu-link" @click="mobileMenuOpen = false">
                  {{ t('contact') || 'اتصل بنا' }}
                </NuxtLink>
              </div>
            </div>
            
            <!-- Account Links -->
            <div class="mobile-menu-section">
              <h4>{{ t('account') || 'الحساب' }}</h4>
              <div class="mobile-menu-links">
                <template v-if="auth?.user?.value">
                  <NuxtLink :to="getLocalizedPath('/account')" class="mobile-menu-link" @click="mobileMenuOpen = false">
                    {{ t('my_account') || 'حسابي' }}
                  </NuxtLink>
                  <NuxtLink :to="getLocalizedPath('/account/orders')" class="mobile-menu-link" @click="mobileMenuOpen = false">
                    {{ t('my_orders') || 'طلباتي' }}
                  </NuxtLink>
                  <NuxtLink :to="getLocalizedPath('/account/wishlist')" class="mobile-menu-link" @click="mobileMenuOpen = false">
                    {{ t('wishlist') || 'قائمة الأمنيات' }}
                  </NuxtLink>
                  <button class="mobile-menu-link logout-btn" @click="handleLogout">
                    {{ t('logout') || 'تسجيل الخروج' }}
                  </button>
                </template>
                <template v-else>
                  <button class="mobile-menu-link" @click="openLoginModal(); mobileMenuOpen = false">
                    {{ t('login') || 'تسجيل الدخول' }}
                  </button>
                  <button class="mobile-menu-link" @click="openRegisterModal(); mobileMenuOpen = false">
                    {{ t('register') || 'إنشاء حساب' }}
                  </button>
                </template>
              </div>
            </div>
          </div>
        </div>
      </div>
    </teleport>

    <!-- Search Overlay -->
    <teleport to="body">
      <div v-if="searchOpen" class="search-overlay" @click.self="searchOpen = false">
        <div class="so-header">
          <div class="so-search">
            <svg  width="30" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier"> <path d="M11 6C13.7614 6 16 8.23858 16 11M16.6588 16.6549L21 21M19 11C19 15.4183 15.4183 19 11 19C6.58172 19 3 15.4183 3 11C3 6.58172 6.58172 3 11 3C15.4183 3 19 6.58172 19 11Z" stroke="#111111" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path> </g></svg>
            <input v-model="q" type="text" :placeholder="t('search.placeholder')" @keyup.enter="goSearch()" autofocus />
          </div>
          <button class="text-btn" @click="searchOpen = false">{{ t('search.close') }}</button>
        </div>

        <div class="so-body">

          <div class="suggest" v-if="q && (suggestions.length || products.length)">
            <div class="s-col">
              <div class="s-title">{{ t('search.suggestions_title') }}</div>
              <div class="s-item" v-for="(s,i) in suggestions" :key="i" @click="goSearch(s)">
                <svg width="16" height="16" viewBox="0 0 24 24"><path fill="currentColor" d="M9.5 3A6.5 6.5 0 0 1 16 9.5c0 1.6-.58 3.07-1.54 4.2l.2.2h.84l5 5l-1.5 1.5l-5-5v-.84l-.2-.2A6.516 6.516 0 0 1 9.5 16A6.5 6.5 0 0 1 3 9.5A6.5 6.5 0 0 1 9.5 3Z"/></svg>
                <span v-html="s"></span>
              </div>
            </div>
            <div class="s-col">
              <div class="s-title">{{ t('search.products') }} ({{ products.length }})</div>
              <NuxtLink class="p-item" v-for="(p,i) in products" :key="i" :to="{ path:'/product/'+(p?.slug || p?.id), query: { from: 'search' } }" @click="handleProductClick">
                <img :src="p?.thumbnail_full_url?.path|| p?.thumbnail || 'https://dummyimage.com/56x56/f0f0f0/aaa'" alt="p" />
                <div class="p-info">
                  <div class="p-name">{{ p?.name || p?.product_name || t('search.product') }}</div>
                  <div class="p-price" v-if="p?.price">
                    <b>{{ p.price }}</b>
                  </div>
                </div>
              </NuxtLink>
            </div>
          </div>
        </div>
      </div>
    </teleport>

    <!-- Success Message -->
    <teleport to="body">
      <div v-if="loginSuccess || registerSuccess || logoutSuccess" class="global-success-message">
        <div class="success-content">
          <svg width="20" height="20" viewBox="0 0 24 24">
            <path fill="currentColor" d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/>
          </svg>
          <span v-if="loginSuccess">{{ t('login.success') || 'تم تسجيل الدخول بنجاح' }}</span>
          <span v-else-if="registerSuccess">{{ t('register.success') || 'تم إنشاء الحساب بنجاح' }}</span>
          <span v-else-if="logoutSuccess">{{ t('logout.success') || 'تم تسجيل الخروج بنجاح' }}</span>
        </div>
      </div>
    </teleport>

    <!-- Login Modal -->
    <teleport to="body">
      <div v-if="loginModalOpen" class="login-overlay" @click.self="closeLoginModal">
        <div class="login-modal" :dir="uiDir">
          <div class="login-header">
            <h2>{{ t('login') || 'تسجيل الدخول' }}</h2>
            <button class="close-btn" @click="closeLoginModal">
              <svg width="20" height="20" viewBox="0 0 24 24"><path fill="currentColor" d="M19 6.41L17.59 5L12 10.59L6.41 5L5 6.41L10.59 12L5 17.59L6.41 19L12 13.41L17.59 19L19 17.59L13.41 12z"/></svg>
            </button>
          </div>
          
          <form @submit.prevent="handleLogin" class="login-form">
            <div class="form-group">
              <label for="email">{{ t('email') || 'البريد الإلكتروني' }}</label>
              <input 
                id="email"
                v-model="loginForm.email" 
                type="email" 
                :placeholder="t('email') || 'البريد الإلكتروني'"
                required
                :disabled="loginLoading"
              />
            </div>
            
            <div class="form-group">
              <label for="password">{{ t('password') || 'كلمة المرور' }}</label>
              <input 
                id="password"
                v-model="loginForm.password" 
                type="password" 
                :placeholder="t('password') || 'كلمة المرور'"
                required
                :disabled="loginLoading"
              />
            </div>
            
            <div v-if="loginError" class="error-message">
              {{ loginError }}
            </div>
            
            <div v-if="loginSuccess" class="success-message">
              <svg width="16" height="16" viewBox="0 0 24 24">
                <path fill="currentColor" d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/>
              </svg>
              {{ t('login.success') || 'تم تسجيل الدخول بنجاح' }}
            </div>
            
            <button type="submit" class="login-btn2" style="    width: 100%;background: #232323;color: #fff;padding: 10px;border-radius: 10px;" :disabled="loginLoading">
              <span v-if="loginLoading">{{ t('loading') || 'جاري التحميل...' }}</span>
              <span v-else>{{ t('login') || 'تسجيل الدخول' }}</span>
            </button>
          </form>
          
          <div class="login-footer">
            <p>{{ t('no_account') || 'ليس لديك حساب؟' }} 
              <a href="#" @click.prevent="openRegisterModal">
                {{ t('register') || 'إنشاء حساب' }}
              </a>
            </p>
          </div>
        </div>
      </div>
    </teleport>

    <!-- Register Modal -->
    <teleport to="body">
      <div v-if="showRegisterModal" class="login-overlay" @click.self="closeRegisterModal">
        <div class="login-modal" :dir="uiDir">
          <div class="login-header">
            <h2>{{ t('register') || 'إنشاء حساب جديد' }}</h2>
            <button class="close-btn" @click="closeRegisterModal">
              <svg width="20" height="20" viewBox="0 0 24 24"><path fill="currentColor" d="M19 6.41L17.59 5L12 10.59L6.41 5L5 6.41L10.59 12L5 17.59L6.41 19L12 13.41L17.59 19L19 17.59L13.41 12z"/></svg>
            </button>
          </div>
          
          <form @submit.prevent="handleRegisterSubmit" class="login-form">
            <div class="form-row">
              <div class="form-group">
                <label for="f_name">{{ t('first_name') || 'الاسم الأول' }} *</label>
                <input 
                  id="f_name" 
                  v-model="registerForm.f_name" 
                  type="text" 
                  :placeholder="t('first_name') || 'الاسم الأول'" 
                  required 
                  :disabled="registerLoading" 
                />
              </div>
              <div class="form-group">
                <label for="l_name">{{ t('last_name') || 'الاسم الأخير' }} *</label>
                <input 
                  id="l_name" 
                  v-model="registerForm.l_name" 
                  type="text" 
                  :placeholder="t('last_name') || 'الاسم الأخير'" 
                  required 
                  :disabled="registerLoading" 
                />
              </div>
            </div>

            <div class="form-group">
              <label for="register_email">{{ t('email') || 'البريد الإلكتروني' }} *</label>
              <input 
                id="register_email" 
                v-model="registerForm.email" 
                type="email" 
                :placeholder="t('email') || 'البريد الإلكتروني'" 
                required 
                :disabled="registerLoading" 
              />
            </div>

            <div class="form-group">
              <label for="register_phone">{{ t('phone') || 'رقم الهاتف' }} *</label>
              <input 
                id="register_phone" 
                v-model="registerForm.phone" 
                type="tel" 
                :placeholder="t('phone') || 'رقم الهاتف'" 
                required 
                :disabled="registerLoading" 
              />
            </div>

            <div class="form-row">
              <div class="form-group">
                <label for="register_password">{{ t('password') || 'كلمة المرور' }} *</label>
                <input 
                  id="register_password" 
                  v-model="registerForm.password" 
                  type="password" 
                  :placeholder="t('password') || 'كلمة المرور'" 
                  required 
                  :disabled="registerLoading" 
                />
              </div>
              <div class="form-group">
                <label for="password_confirmation">{{ t('confirm_password') || 'تأكيد كلمة المرور' }} *</label>
                <input 
                  id="password_confirmation" 
                  v-model="registerForm.password_confirmation" 
                  type="password" 
                  :placeholder="t('confirm_password') || 'تأكيد كلمة المرور'" 
                  required 
                  :disabled="registerLoading" 
                />
              </div>
            </div>

            <div class="form-group">
              <label for="referral_code">{{ t('referral_code') || 'كود الإحالة' }} ({{ t('optional') || 'اختياري' }})</label>
              <input 
                id="referral_code" 
                v-model="registerForm.referral_code" 
                type="text" 
                :placeholder="t('referral_code') || 'كود الإحالة'" 
                :disabled="registerLoading" 
              />
            </div>

            <div v-if="registerError" class="error-message">
              {{ registerError }}
            </div>

            <div v-if="registerSuccess" class="success-message">
              <svg width="16" height="16" viewBox="0 0 24 24">
                <path fill="currentColor" d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/>
              </svg>
              {{ t('register.success') || 'تم إنشاء الحساب بنجاح' }}
            </div>

            <button type="submit" class="login-btn" :disabled="registerLoading">
              <span v-if="registerLoading">{{ t('creating_account') || 'جاري إنشاء الحساب...' }}</span>
              <span v-else>{{ t('register') || 'إنشاء حساب' }}</span>
            </button>
          </form>
          
          <div class="login-footer">
            <p>{{ t('have_account') || 'لديك حساب بالفعل؟' }} 
              <a href="#" @click.prevent="openLoginModal(); closeRegisterModal()">
                {{ t('login') || 'تسجيل الدخول' }}
              </a>
            </p>
          </div>
        </div>
      </div>
    </teleport>

    <!-- Global Loading Overlay -->
    <teleport to="body">
      <div v-if="globalLoading" class="global-loading-overlay">
        <div class="global-loading-container">
          <div class="global-loading-spinner">
            <div class="spinner-ring"></div>
            <div class="spinner-ring"></div>
            <div class="spinner-ring"></div>
          </div>
          
          <div class="global-loading-progress">
            <div class="progress-bar" :style="{ width: loadingProgress + '%' }"></div>
          </div>
          
          <div class="global-loading-message">
            {{ loadingMessage }}
          </div>
          
          <div class="global-loading-dots">
            <span></span>
            <span></span>
            <span></span>
          </div>
        </div>
      </div>
    </teleport>

    <!-- Bottom navigation (mobile) -->
    <nav class="bottom-nav">
      <NuxtLink :to="getLocalizedPath('/')" class="bn-item">
        <svg width="22" height="22" viewBox="0 0 24 24"><path fill="currentColor" d="M10 20v-6h4v6h5v-8h3L12 3L2 12h3v8z"/></svg>
        <span>{{ t('home') }}</span>
      </NuxtLink>
      <NuxtLink :to="getLocalizedPath('/categories')" class="bn-item">
        <svg width="22" height="22" viewBox="0 0 24 24"><path fill="currentColor" d="M3 6h18v2H3V6m0 5h18v2H3v-2m0 5h18v2H3v-2Z"/></svg>
        <span>{{ t('categories') }}</span>
      </NuxtLink>
      <template v-if="auth?.user?.value">
        <NuxtLink :to="getLocalizedPath('/account?tab=wishlist')" class="bn-item">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M20.84 4.61C20.3292 4.099 19.7228 3.69364 19.0554 3.41708C18.3879 3.14052 17.6725 2.99817 16.95 2.99817C16.2275 2.99817 15.5121 3.14052 14.8446 3.41708C14.1772 3.69364 13.5708 4.099 13.06 4.61L12 5.67L10.94 4.61C9.9083 3.5783 8.50903 2.9987 7.05 2.9987C5.59096 2.9987 4.19169 3.5783 3.16 4.61C2.1283 5.6417 1.5487 7.04097 1.5487 8.5C1.5487 9.95903 2.1283 11.3583 3.16 12.39L12 21.23L20.84 12.39C21.351 11.8792 21.7563 11.2728 22.0329 10.6053C22.3095 9.93789 22.4518 9.22248 22.4518 8.5C22.4518 7.77752 22.3095 7.06211 22.0329 6.39467C21.7563 5.72723 21.351 5.1208 20.84 4.61Z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <span>{{ t('wishlist') }}</span>
        </NuxtLink>
      </template>
      <template v-else>
        <button @click="openLoginModal" class="bn-item">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M20.84 4.61C20.3292 4.099 19.7228 3.69364 19.0554 3.41708C18.3879 3.14052 17.6725 2.99817 16.95 2.99817C16.2275 2.99817 15.5121 3.14052 14.8446 3.41708C14.1772 3.69364 13.5708 4.099 13.06 4.61L12 5.67L10.94 4.61C9.9083 3.5783 8.50903 2.9987 7.05 2.9987C5.59096 2.9987 4.19169 3.5783 3.16 4.61C2.1283 5.6417 1.5487 7.04097 1.5487 8.5C1.5487 9.95903 2.1283 11.3583 3.16 12.39L12 21.23L20.84 12.39C21.351 11.8792 21.7563 11.2728 22.0329 10.6053C22.3095 9.93789 22.4518 9.22248 22.4518 8.5C22.4518 7.77752 22.3095 7.06211 22.0329 6.39467C21.7563 5.72723 21.351 5.1208 20.84 4.61Z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <span>{{ t('wishlist') }}</span>
        </button>
      </template>
      <NuxtLink :to="getLocalizedPath('/cart')" class="bn-item">
        <div class="bn-icon-wrapper">
          <svg width="25" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier"><path d="M20.2236 12.5257C19.6384 9.40452 19.3458 7.84393 18.2349 6.92196C17.124 6 15.5362 6 12.3606 6H11.6394C8.46386 6 6.87608 6 5.76518 6.92196C4.65428 7.84393 4.36167 9.40452 3.77645 12.5257C2.95353 16.9146 2.54207 19.1091 3.74169 20.5545C4.94131 22 7.17402 22 11.6394 22H12.3606C16.826 22 19.0587 22 20.2584 20.5545C20.9543 19.7159 21.108 18.6252 20.9537 17" stroke="#000000" stroke-width="1.5" stroke-linecap="round"></path> <path d="M9 6V5C9 3.34315 10.3431 2 12 2C13.6569 2 15 3.34315 15 5V6" stroke="#000000" stroke-width="1.5" stroke-linecap="round"></path></g></svg>
          <span v-if="cartCount > 0" class="bn-cart-badge">{{ cartCount }}</span>
        </div>
        <span>{{ t('bag') }}</span>
      </NuxtLink>
      <template v-if="auth?.user?.value">
        <NuxtLink :to="getLocalizedPath('/account')" class="bn-item">
          <svg width="22" height="22" viewBox="0 0 24 24"><path fill="currentColor" d="M12 19.2c-2.5 0-7.5 1.25-7.5 3.75V25h15v-2.05c0-2.5-5-3.75-7.5-3.75M12 2a5 5 0 0 0-5 5a5 5 0 0 0 10 0a5 5 0 0 0-5-5Z"/></svg>
          <span>{{ t('account') }}</span>
        </NuxtLink>
      </template>
      <template v-else>
        <button @click="openLoginModal" class="bn-item">
          <svg width="22" height="22" viewBox="0 0 24 24"><path fill="currentColor" d="M12 19.2c-2.5 0-7.5 1.25-7.5 3.75V25h15v-2.05c0-2.5-5-3.75-7.5-3.75M12 2a5 5 0 0 0-5 5a5 5 0 0 0 10 0a5 5 0 0 0-5-5Z"/></svg>
          <span>{{ t('login') }}</span>
        </button>
      </template>
    </nav>
  </header>
</template>

<style scoped>
@import url('https://fonts.googleapis.com/css2?family=Cairo:wght@200..1000&family=IBM+Plex+Sans+Arabic:wght@100;200;300;400;500;600;700&family=Tajawal:wght@200;300;400;500;700;800;900&display=swap');
body {
  font-family: "Tajawal", sans-serif !important;
}
.cart-btn {
  background: #2675BA !important;
}
.logo-img {
  width: 100px;
  height: 100%;
  object-fit: contain;
}
.categories-icon {
  background: #232323;
  padding: 5px;
  border-radius: 50%;
}
/* Main Header Container */
.app-header { 
  background: #1a1a1a;
  position: sticky; 
  top: 0; 
  z-index: 1000;
  box-shadow: 0 2px 20px rgba(0, 0, 0, 0.08);
  border-bottom: 1px solid #f0f0f0;
  width: 100%;
  transition: all 0.3s ease;
}

.container { 
  max-width: 1400px; 
  margin: 0 auto; 
  padding: 0 20px; 
}

/* Top Bar */
.top-bar {
  background: linear-gradient(135deg, #E1EDFF 0%, #764ba2 100%);
  color: white;
  padding: 8px 0;
  font-size: 14px;
}

.top-bar .container {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.tagline {
  display: flex;
  align-items: center;
  gap: 8px;
  font-weight: 500;
}

.tagline-icon {
  color: #ffd700;
}

.delivery-info {
  display: flex;
  align-items: center;
  gap: 6px;
  cursor: pointer;
  padding: 4px 8px;
  border-radius: 6px;
  transition: background-color 0.2s ease;
}

.delivery-info:hover {
  background: rgba(255, 255, 255, 0.1);
}

.location-icon {
  color: #ffd700;
}

.chevron {
  transition: transform 0.2s ease;
}

.delivery-info:hover .chevron {
  transform: rotate(180deg);
}

/* Main Header */
.main-header {
  padding: 16px 0;
  border-bottom: 1px solid #f0f0f0;
}

/* Logo Section */
.logo-section {
  display: flex;
  align-items: center;
}

.brand {
  color: inherit;
  text-decoration: none;
  transition: transform 0.2s ease;
}

.brand:hover {
  transform: scale(1.02);
}

.logo-container {
  display: flex;
  align-items: center;
  gap: 12px;
}

.logo-circle {
  width: 48px;
  height: 48px;
  border-radius: 50%;
  background: linear-gradient(135deg, #E1EDFF 0%, #764ba2 100%);
  color: #fff;
  display: flex;
  align-items: center;
  justify-content: center;
  font-weight: 700;
  font-size: 20px;
  box-shadow: 0 4px 12px rgba(102, 126, 234, 0.3);
}

.brand-text {
  display: flex;
  flex-direction: column;
  gap: 2px;
}

.brand-arabic {
  font-weight: 700;
  font-size: 18px;
  color: #333;
  line-height: 1.2;
}

.brand-english {
  font-weight: 600;
  font-size: 14px;
  color: #666;
  letter-spacing: 1px;
}

/* Search Section */
.search-section {
  display: flex;
  justify-content: center;
}

.search-container {
  width: 100%;
}

.search-box {
  display: flex;
  align-items: center;
  gap: 12px;
  border: 2px solid #f0f0f0;
  border-radius: 50px;
  padding: 8px 20px;
  background: #fafafa;
  cursor: pointer;
  transition: all 0.3s ease;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
}

.search-box:hover {
  border-color: #E1EDFF;
  background: #fff;
  box-shadow: 0 4px 16px #F58040;
}

.search-icon {
  color: #999;
  transition: color 0.2s ease;
}

.search-box:hover .search-icon {
  color: #E1EDFF;
}

.search-input {
  border: 0;
  outline: 0;
  background: transparent;
  width: 100%;
  font-size: 16px;
  color: #333;
}

.search-input::placeholder {
  color: #999;
}

/* Language Selector */
.lang {
  position: relative;
}

.lang-btn {
  display: flex;
  align-items: center;
  gap: 8px;
  border: 1px solid #e0e0e0;
  border-radius: 12px;
  padding: 10px 14px;
  background: #fff;
  cursor: pointer;
  transition: all 0.2s ease;
  font-weight: 500;
  color: #333;
}

.lang-btn:hover {
  border-color: #E1EDFF;
  background: #f8f9ff;
  box-shadow: 0 2px 8px #F58040;
}

#__nuxt [dir="rtl"] .lang-menu  {
  position: absolute;
  top: calc(100% + 8px);
  left: 0;
  background: #fff;
  border: 1px solid #e0e0e0;
  border-radius: 16px;
  box-shadow: 0 10px 40px rgba(0, 0, 0, 0.15);
  width: 280px;
  padding: 16px;
  z-index: 60;
  animation: slideDown 0.2s ease-out;
}
#__nuxt [dir="ltr"] .lang-menu {
  position: absolute;
  top: calc(100% + 8px);
  right: 0;
  background: #fff;
  border: 1px solid #e0e0e0;
  border-radius: 16px;
  box-shadow: 0 10px 40px rgba(0, 0, 0, 0.15);
  width: 280px;
  padding: 16px;
  z-index: 60;
  animation: slideDown 0.2s ease-out;
}
@keyframes slideDown {
  from {
    opacity: 0;
    transform: translateY(-10px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

.lang-title {
  text-align: center;
  font-weight: 700;
  color: #333;
  margin-bottom: 12px;
  font-size: 16px;
}

.lang-grid {
  display: grid;
  gap: 8px;
}

.lang-card {
  background: #fff;
  border: 2px solid #f0f0f0;
  border-radius: 12px;
  padding: 12px;
  cursor: pointer;
  transition: all 0.2s ease;
}

.lang-card:hover {
  border-color: #e0e0e0;
  background: #f8f9ff;
}

.lang-card.checked {
  border-color: #E1EDFF;
  background: #f8f9ff;
}

.lang-card .row {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
}

.lang-card .meta {
  display: flex;
  align-items: center;
  gap: 10px;
}

.lang-card .label {
  font-weight: 600;
  color: #333;
}

.lang-card .flag {
  font-size: 20px;
}

.lang-card .radio {
  width: 20px;
  height: 20px;
  border: 2px solid #ddd;
  border-radius: 50%;
  position: relative;
  transition: all 0.2s ease;
}

.lang-card .radio.checked {
  border-color: #E1EDFF;
}

.lang-card .radio.checked::after {
  content: '';
  position: absolute;
  inset: 4px;
  background: #E1EDFF;
  border-radius: 50%;
}

/* Profile Section */
.profile {
  display: flex;
  align-items: center;
  gap: 12px;
}

.profile-btn, .login-btn {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 10px;
  border: 1px solid #e0e0e0;
  border-radius: 50%;
  background: #fff;
  color: #333;
  text-decoration: none;
  cursor: pointer;
  transition: all 0.2s ease;
  font-weight: 500;
}

.profile-btn:hover, .login-btn:hover {
  border-color: #E1EDFF;
  background: #f8f9ff;
  color: #E1EDFF;
  box-shadow: 0 2px 8px #F58040;
}

.logout-btn {
  background: transparent;
  border: 1px solid #e0e0e0;
  color: #666;
  padding: 8px 12px;
  border-radius: 8px;
  cursor: pointer;
  transition: all 0.2s ease;
  font-size: 14px;
}

.logout-btn:hover {
  background: #fee;
  border-color: #fcc;
  color: #c53030;
}

/* Action Buttons */
.action-btn {
  position: relative;
  display: flex;
  align-items: center;
  justify-content: center;
  width: 44px;
  height: 44px;
  padding: 12px 5px;
  border: 1px solid #e0e0e0;
  border-radius: 50%;
  background: #fff;
  color: #333;
  cursor: pointer;
  transition: all 0.2s ease;
  text-decoration: none;
}

.action-btn:hover {
  border-color: #E1EDFF;
  background: #f8f9ff;
  color: #E1EDFF;
  box-shadow: 0 2px 8px #F58040;
}

.notification-badge, .cart-badge, .wishlist-badge, .compare-badge {
  position: absolute;
  top: -6px;
  right: -6px;
  background: #ff4757;
  color: white;
  border-radius: 50%;
  width: 20px;
  height: 20px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 11px;
  font-weight: 600;
  border: 2px solid #fff;
}

/* Navigation Bar */
.nav-bar {
  background: #f8f9fa;
  padding: 5px 0;
  border-bottom: 1px solid #e0e0e0;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
}

.nav-bar .container {
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.nav-left {
  display: flex;
  align-items: center;
}

.categories-dropdown {
  position: relative;
}

.categories-btn {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 10px;
  border: 1px solid #e0e0e0;
  border-radius: 30px;
  background: #fff;
  cursor: pointer;
  transition: all 0.2s ease;
  font-weight: 600;
  color: #333;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
}

.categories-btn:hover {
  border-color: #E1EDFF;
  background: #f8f9ff;
  color: #000000;
  box-shadow: 0 4px 12px rgba(102, 126, 234, 0.15);
}
.categories-btn .categories-icon:hover {
  color: #ffffff;
}

.nav-center {
  flex: 1;
  display: flex;
  justify-content: center;
  align-items: center;
}

.nav-links {
  display: flex;
  gap: 8px;
  align-items: center;
  flex-wrap: wrap;
  justify-content: center;
  }

.nav-link {
  color: #333;
  text-decoration: none;
  font-weight: 600;
  padding: 12px 10px;
  border-radius: 8px;
  transition: all 0.3s ease;
  position: relative;
  white-space: nowrap;
  font-size: 14px;
  display: flex;
  align-items: center;
  gap: 8px;
  text-align: center;
  justify-content: center;
}

.nav-link:hover {
  color: #E1EDFF;
  background: #F58040;
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(102, 126, 234, 0.2);
}

.nav-link::after {
  content: '';
  position: absolute;
  bottom: -3px;
  left: 50%;
  transform: translateX(-50%);
  width: 0;
  height: 3px;
  background: linear-gradient(135deg, #E1EDFF 0%, #764ba2 100%);
  transition: width 0.3s ease;
  border-radius: 2px;
}

.nav-link:hover::after {
  width: 90%;
}

.nav-link:active {
  transform: translateY(-1px);
}

/* Navigation Icons */
.nav-icon {
  flex-shrink: 0;
  transition: all 0.3s ease;
}

/* Active Navigation Link */
.nav-link.active {
  color: #F58040;
  background: transparent;
}

.nav-link.active::after {
  content: '';
  position: absolute;
  bottom: -3px;
  left: 50%;
  transform: translateX(-50%);
  width: 90%;
  height: 3px;
  background: #F58040;
  border-radius: 2px;
}

.nav-link.active .nav-icon {
  color: #F58040;
}

/* Navigation Item with Dropdown */
.nav-item {
  position: relative;
  display: inline-block;
}

.nav-link {
  display: flex;
  align-items: center;
  gap: 6px;
}

.nav-arrow {
  transition: transform 0.2s ease;
  opacity: 0.7;
}

.nav-item:hover .nav-arrow {
  transform: rotate(180deg);
  opacity: 1;
}

/* Subcategories Dropdown */
.subcategories-dropdown {
  position: absolute;
  top: 80%;
  left: 0;
  background: #fff;
  border: 1px solid #e0e0e0;
  border-radius: 12px;
  box-shadow: 0 10px 40px rgba(0, 0, 0, 0.15);
  z-index: 100;
  min-width: 400px;
  animation: slideDown 0.2s ease-out;
  margin-top: 8px;
}

.subcategories-content {
  padding: 16px 0;
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 0;
  max-height: 300px;
  overflow-y: auto;
}

.subcategory-link {
  display: block;
  padding: 12px 16px;
  color: #333;
  text-decoration: none;
  font-weight: 500;
  font-size: 14px;
  transition: all 0.2s ease;
  border-left: 3px solid transparent;
  border-bottom: 1px solid #f0f0f0;
  text-align: center;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.subcategory-link:hover {
  background: #F58040;
  color: #E1EDFF;
  border-left-color: #E1EDFF;
  transform: translateY(-1px);
  box-shadow: 0 2px 8px rgba(102, 126, 234, 0.2);
}

.subcategory-link:nth-child(3n+1) {
  border-top-left-radius: 12px;
}

.subcategory-link:nth-child(3n) {
  border-top-right-radius: 12px;
}

.subcategory-link:nth-last-child(-n+3) {
  border-bottom: none;
}

.subcategory-link:nth-last-child(1) {
  border-bottom-left-radius: 12px;
}

.subcategory-link:nth-last-child(2) {
  border-bottom-right-radius: 12px;
}

/* RTL Support for Subcategories */
[dir="rtl"] .subcategories-dropdown {
  left: auto;
  right: 0;
}

[dir="rtl"] .subcategory-link {
  border-left: none;
  border-right: 3px solid transparent;
  text-align: center;
}

[dir="rtl"] .subcategory-link:hover {
  border-left-color: transparent;
  border-right-color: #E1EDFF;
}

[dir="rtl"] .subcategory-link:nth-child(3n+1) {
  border-top-left-radius: 0;
  border-top-right-radius: 12px;
}

[dir="rtl"] .subcategory-link:nth-child(3n) {
  border-top-right-radius: 0;
  border-top-left-radius: 12px;
}

[dir="rtl"] .subcategory-link:nth-last-child(1) {
  border-bottom-left-radius: 0;
  border-bottom-right-radius: 12px;
}

[dir="rtl"] .subcategory-link:nth-last-child(2) {
  border-bottom-right-radius: 0;
  border-bottom-left-radius: 12px;
}

/* Mega Menu */
.mega-menu {
  position: absolute;
  top: calc(100% + 0px);
  right: 0;
  background: #fff;
  border: 1px solid #e0e0e0;
  border-radius: 16px;
  box-shadow: 0 20px 60px rgba(0, 0, 0, 0.15);
  width: min(1000px, 90vw);
  z-index: 60;
  animation: slideDown 0.3s ease-out;
}
[dir="ltr"] .mega-menu  {
  right: auto;
  left: 0;
}
.mega-content {
  display: grid;
  grid-template-columns: 280px 1fr;
  gap: 0;
  padding: 0;
  min-height: 500px;
  max-height: 600px;
}

/* Main Categories Column */
.mega-main-categories {
  background: #f8f9ff;
  border-radius: 16px 0 0 16px;
  padding: 20px 0;
  border-right: 1px solid #e0e0e0;
  overflow-y: auto;
  max-height: 600px;
}

.mega-category-item {
  position: relative;
  transition: all 0.2s ease;
}

.mega-category-item:hover {
  background: rgba(245, 128, 64, 0.1);
}

.mega-title {
  display: flex;
  align-items: center;
  justify-content: space-between;
  font-weight: 700;
  color: #333;
  padding: 16px 24px;
  cursor: pointer;
  transition: all 0.3s ease;
  border-right: 3px solid transparent;
  font-size: 16px;
}

.mega-title:hover {
  color: #ffffff;
  background: #F58040;
  border-right-color: #F58040;
  transform: translateX(4px);
}

.mega-arrow {
  transition: transform 0.2s ease;
  opacity: 0.7;
}

.mega-category-item:hover .mega-arrow {
  transform: rotate(90deg);
  opacity: 1;
}

/* Subcategories Area */
.mega-subcategories-area {
  padding: 20px;
  display: flex;
  align-items: flex-start;
  position: relative;
}

.mega-subcategories {
  width: 100%;
}

.mega-subcategories-content {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 16px;
  max-height: 500px;
  overflow-y: auto;
  position: relative;
  z-index: 1;
  padding: 20px;
}

.mega-subcategory-item {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 20px 16px;
  color: #333;
  text-decoration: none;
  font-weight: 600;
  font-size: 14px;
  transition: all 0.3s ease;
  border: 1px solid #e5e7eb;
  border-radius: 12px;
  background: #ffffff;
  text-align: center;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  cursor: pointer;
  position: relative;
  min-height: 80px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
}

.mega-subcategory-item:hover {
  background: #F58040;
  color: #ffffff;
  border-color: #F58040;
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(245, 128, 64, 0.3);
  z-index: 2;
}

.mega-subcategory-item:nth-child(3n+1) {
  border-top-left-radius: 12px;
}

.mega-subcategory-item:nth-child(3n) {
  border-top-right-radius: 12px;
}

.mega-subcategory-item:nth-last-child(-n+3) {
  border-bottom: none;
}

.mega-subcategory-item:nth-last-child(1) {
  border-bottom-left-radius: 12px;
}

.mega-subcategory-item:nth-last-child(2) {
  border-bottom-right-radius: 12px;
}

/* Mega Menu Scrollbar */
.mega-main-categories::-webkit-scrollbar,
.mega-subcategories-content::-webkit-scrollbar {
  width: 6px;
}

.mega-main-categories::-webkit-scrollbar-track,
.mega-subcategories-content::-webkit-scrollbar-track {
  background: #f1f5f9;
  border-radius: 3px;
}

.mega-main-categories::-webkit-scrollbar-thumb,
.mega-subcategories-content::-webkit-scrollbar-thumb {
  background: #cbd5e1;
  border-radius: 3px;
}

.mega-main-categories::-webkit-scrollbar-thumb:hover,
.mega-subcategories-content::-webkit-scrollbar-thumb:hover {
  background: #94a3b8;
}

/* Placeholder when no subcategory is hovered */
.mega-placeholder {
  display: flex;
  flex-direction: column;
  gap: 16px;
  align-items: center;
  justify-content: center;
  width: 100%;
  height: 100%;
  min-height: 350px;
}

.mega-placeholder img {
  border-radius: 12px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
}

.brands {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  justify-content: center;
}

.brands img {
  width: 60px;
  height: 30px;
  object-fit: contain;
  border-radius: 6px;
  opacity: 0.8;
  transition: opacity 0.2s ease;
}

.brands img:hover {
  opacity: 1;
}

/* Right Actions (Legacy) */
.right { display: flex; align-items: center; justify-content: flex-end; gap: 12px; }
.action { display: inline-flex; align-items: center; gap: 8px; color: #555; }
.icon-btn { display: inline-flex; align-items: center; justify-content: center; width: 40px; height: 40px; border-radius: 50%; border: 1px solid #eee; }
.text-btn { background: transparent; border: 0; color: #6b46c1; cursor: pointer; }
.profile { display: inline-flex; align-items: center; gap: 10px; }

/* Language dropdown */
.lang { position: relative; }
.lang-btn { display: inline-flex; align-items: center; gap: 6px; border: 1px solid #eee; border-radius: 10px; padding: 8px 10px; background: #fff; cursor: pointer; }
.lang-menu { position: absolute; top: calc(100% + 0); inset-inline-end: 0; background: #fff; border: 1px solid #eee; border-radius: 12px; box-shadow: 0 10px 28px rgba(0,0,0,.12); width: 360px; padding: 12px; z-index: 50; }
.lang-title { text-align: center; font-weight: 700; color: #777; margin-bottom: 10px; }
.lang-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
.lang-card { background: #fff; border: 1px solid #eee; border-radius: 12px; padding: 12px; cursor: pointer; text-align: start; }
.lang-card:hover { border-color: #d9d9d9; background: #fafafa; }
.lang-card .row { display: flex; align-items: center; justify-content: space-between; gap: 8px; }
.lang-card .label { font-weight: 600; }
.lang-card .meta { display: inline-flex; align-items: center; gap: 8px; color: #555; }
.lang-card .badge { background: #eef7ee; color: #2b8a3e; border: 1px solid #d1ecd1; border-radius: 6px; padding: 2px 6px; font-size: 12px; }
.lang-card .flag { font-size: 18px; }
.lang-card .radio { width: 18px; height: 18px; border: 2px solid #bbb; border-radius: 50%; display: inline-block; position: relative; }
.lang-card .radio.checked { border-color: #6b46c1; }
.lang-card .radio.checked::after { content: ''; position: absolute; inset: 3px; background: #6b46c1; border-radius: 50%; }

.search-overlay { position: fixed; inset: 0; background: rgba(0,0,0,.35); z-index: 1001; display: grid; place-items: start center; padding-top: 6vh; }
.search-overlay .so-header { width: min(980px, 92vw); background: #fff; border-radius: 16px; padding: 12px; display: flex; align-items: center; justify-content: space-between; gap: 12px; box-shadow: 0 6px 18px rgba(0,0,0,.12); }
.so-search { flex: 1; display: flex; align-items: center; gap: 8px; border: 1px solid #eee; border-radius: 12px; padding: 10px 12px; }
.so-search input { border: 0; outline: 0; width: 100%; }

.so-body { width: min(980px, 92vw); background: #fff; border-radius: 16px; margin-top: 10px; padding: 16px; box-shadow: 0 6px 18px rgba(0,0,0,.12); max-height: 60vh; overflow-y: auto; }
.chips { display: flex; flex-wrap: wrap; gap: 10px; }
.chip { padding: 8px 12px; border: 1px solid #e5e5e5; border-radius: 999px; cursor: pointer; background: #fff; }
.chip:hover { background: #faf7ff; border-color: #e0d7ff; }
.brands-grid { display: grid; grid-template-columns: repeat(6, 1fr); gap: 12px; margin: 16px 0; }
.brands-grid img { width: 100%; height: 76px; object-fit: contain; border: 1px solid #eee; border-radius: 12px; background: #fff; }

.suggest { display: grid; grid-template-columns: 1fr 2fr; gap: 16px; margin-top: 10px; }
.s-col:last-child { max-height: 400px; overflow-y: auto; }
.s-title { font-weight: 700; margin-bottom: 8px; }
.s-item { display: flex; align-items: center; gap: 8px; padding: 8px 6px; border-radius: 8px; cursor: pointer; }
.s-item:hover { background: #fafafa; }
.p-item { display: grid; grid-template-columns: 56px 1fr; gap: 10px; align-items: center; padding: 8px; border-radius: 10px; color: inherit; text-decoration: none; }
.p-item:hover { background: #fafafa; }
.p-item img { width: 56px; height: 56px; object-fit: cover; border-radius: 10px; border: 1px solid #eee; }
.p-name { font-size: 14px; line-height: 1.3; }
.p-price { color: #e91e63; }

.bottom-nav { position: fixed; bottom: 0; inset-inline: 0; background: #fff; border-top: 1px solid #eee; display: none; justify-content: space-around; padding: 6px 0; z-index: 45; }
.bn-item { display: inline-flex; flex-direction: column; align-items: center; gap: 2px; color: #444; text-decoration: none; font-size: 12px; background: none; border: none; cursor: pointer; }
.bn-icon-wrapper { position: relative; display: flex; align-items: center; justify-content: center; }
.bn-cart-badge { position: absolute; top: -8px; right: -8px; background: #ff4757; color: white; border-radius: 50%; width: 18px; height: 18px; display: flex; align-items: center; justify-content: center; font-size: 10px; font-weight: 600; border: 2px solid #fff; min-width: 18px; }

/* Login Modal Styles */
.login-overlay {
  position: fixed;
  inset: 0;
  background: rgba(0, 0, 0, 0.5);
  z-index: 1002;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 20px;
}

.login-modal {
  background: #fff;
  border-radius: 16px;
  width: 100%;
  max-width: 400px;
  box-shadow: 0 20px 40px rgba(0, 0, 0, 0.15);
  animation: modalSlideIn 0.3s ease-out;
}

@keyframes modalSlideIn {
  from {
    opacity: 0;
    transform: translateY(-20px) scale(0.95);
  }
  to {
    opacity: 1;
    transform: translateY(0) scale(1);
  }
}

.login-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 20px 24px 16px;
  border-bottom: 1px solid #eee;
}

.login-header h2 {
  margin: 0;
  font-size: 20px;
  font-weight: 700;
  color: #333;
}

.close-btn {
  background: none;
  border: none;
  cursor: pointer;
  padding: 4px;
  border-radius: 6px;
  color: #666;
  display: flex;
  align-items: center;
  justify-content: center;
}

.close-btn:hover {
  background: #f5f5f5;
  color: #333;
}

.login-form {
  padding: 24px;
}

.form-group {
  margin-bottom: 20px;
}

.form-row {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 16px;
}

.form-group label {
  display: block;
  margin-bottom: 6px;
  font-weight: 600;
  color: #333;
  font-size: 14px;
}

.form-group input {
  width: 100%;
  padding: 12px 16px;
  border: 1px solid #ddd;
  border-radius: 8px;
  font-size: 14px;
  transition: border-color 0.2s ease;
  box-sizing: border-box;
}

.form-group input:focus {
  outline: none;
  border-color: #6b46c1;
  box-shadow: 0 0 0 3px rgba(107, 70, 193, 0.1);
}

.form-group input:disabled {
  background: #f5f5f5;
  color: #999;
  cursor: not-allowed;
}

.error-message {
  background: #fee;
  color: #c53030;
  padding: 10px 12px;
  border-radius: 6px;
  font-size: 14px;
  margin-bottom: 16px;
  border: 1px solid #feb2b2;
}

.success-message {
  background: #f0fff4;
  color: #22543d;
  padding: 10px 12px;
  border-radius: 6px;
  font-size: 14px;
  margin-bottom: 16px;
  border: 1px solid #9ae6b4;
  display: flex;
  align-items: center;
  gap: 8px;
  animation: slideIn 0.3s ease-out;
}

@keyframes slideIn {
  from {
    opacity: 0;
    transform: translateY(-10px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

.global-success-message {
  position: fixed;
  top: 20px;
  right: 20px;
  z-index: 10000;
  animation: slideInFromRight 0.3s ease-out;
}

.success-content {
  background: #f0fff4;
  color: #22543d;
  padding: 12px 16px;
  border-radius: 8px;
  font-size: 14px;
  font-weight: 500;
  border: 1px solid #9ae6b4;
  display: flex;
  align-items: center;
  gap: 8px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
  min-width: 200px;
}

@keyframes slideInFromRight {
  from {
    opacity: 0;
    transform: translateX(100%);
  }
  to {
    opacity: 1;
    transform: translateX(0);
  }
}

.login-btn {
  position: relative;
  display: flex;
  align-items: center;
  justify-content: center;
  width: 44px;
  height: 44px;
  padding: 12px 5px;
  border: 1px solid #e0e0e0;
  border-radius: 50%;
  background: #fff;
  color: #333;
  cursor: pointer;
  transition: all 0.2s ease;
  text-decoration: none;
}

.login-btn:hover:not(:disabled) {
  background: #f8f9ff;
}

.login-btn:disabled {
  background: #ccc;
  cursor: not-allowed;
}

.login-footer {
  padding: 16px 24px 24px;
  text-align: center;
  border-top: 1px solid #eee;
}

.login-footer p {
  margin: 0;
  color: #666;
  font-size: 14px;
}

.login-footer a {
  color: #6b46c1;
  text-decoration: none;
  font-weight: 600;
}

.login-footer a:hover {
  text-decoration: underline;
}

/* Responsive Design */
@media (max-width: 1024px) {
  .main-header .container {
    grid-template-columns: 1fr 1.5fr 1fr;
    gap: 16px;
  }
  
  .nav-links {
    gap: 20px;
  }
  
  .mega-content {
    grid-template-columns: repeat(3, minmax(140px, 1fr)) 200px;
    gap: 20px;
    padding: 20px;
  }
}

@media (max-width: 768px) {
  .logo-img {
    width: 80px;
  }
  .mobile-none {
    display: none;
  }
  .container {
    padding: 0 16px;
  }
  
  .top-bar {
    font-size: 12px;
    padding: 6px 0;
  }
  
  .main-header .container {
    grid-template-columns: auto 1fr auto auto;
    gap: 12px;
    padding: 12px 0;
    align-items: center;
  }
  
  .logo-section {
    justify-content: flex-start;
  }
  
  .search-section {
    order: 0;
  }
  
  .actions-section {
    order: 0;
    justify-content: flex-end;
    flex-wrap: nowrap;
    gap: 8px;
  }
  
  .nav-bar {
    display: none;
  }
  
  .nav-links {
    display: flex;
    gap: 12px;
    flex-wrap: wrap;
    justify-content: center;
    min-height: 35px;
  }
  
  .nav-link {
    padding: 6px 10px;
    font-size: 13px;
    min-width: fit-content;
  }
  
  .subcategories-dropdown {
    min-width: 320px;
    margin-top: 6px;
  }
  
  .subcategories-content {
    grid-template-columns: repeat(2, 1fr);
    max-height: 250px;
  }
  
  .subcategory-link {
    padding: 10px 12px;
    font-size: 13px;
  }
  
  .mega-content {
    grid-template-columns: 180px 1fr;
  }
  
  .mega-subcategories-content {
    grid-template-columns: repeat(2, 1fr);
  }
  
  .bottom-nav {
    display: flex;
  }
  
  .mega-menu {
    display: none !important;
  }
  
  .lang-menu {
    width: 260px;
    right: -20px;
  }
  
  .profile-btn, .login-btn {
    padding: 8px 12px;
    font-size: 14px;
  }
  
  .action-btn {
    width: 40px;
    height: 40px;
  }
  
  .notification-badge, .cart-badge, .wishlist-badge, .compare-badge {
    width: 18px;
    height: 18px;
    font-size: 10px;
  }
  
  .mobile-menu-btn {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 40px;
    height: 40px;
    background: #000000;
    border: none;
    border-radius: 8px;
    color: white;
    cursor: pointer;
    transition: all 0.2s ease;
  }
  
  .mobile-menu-btn:hover {
    background: #000000;
    transform: translateY(-1px);
  }
  
  .login-modal {
    margin: 10px;
    max-width: none;
  }
  
  .login-header,
  .login-form,
  .login-footer {
    padding-left: 20px;
    padding-right: 20px;
  }
  
  .form-row {
    grid-template-columns: 1fr;
    gap: 12px;
  }
}

@media (max-width: 480px) {
  .container {
    padding: 0 12px;
  }
  
  .top-bar {
    display: none;
  }
  
  .main-header {
    padding: 12px 0;
  }
  
  .logo-container {
    gap: 8px;
  }
  
  .logo-circle {
    width: 40px;
    height: 40px;
    font-size: 18px;
  }
  
  .brand-arabic {
    font-size: 16px;
  }
  
  .brand-english {
    font-size: 12px;
  }
  
  .search-box {
    padding: 12px 16px;
  }
  
  .search-input {
    font-size: 14px;
  }
  
  .actions-section {
    gap: 8px;
  }
  
  .profile-btn, .login-btn {
    padding: 6px 10px;
    font-size: 12px;
  }
  
  .action-btn {
    width: 36px;
    height: 36px;
  }
  
  .lang-btn {
    padding: 8px 10px;
    font-size: 12px;
  }
  
  .lang-menu {
    width: 240px;
    right: -10px;
  }
  
  .nav-bar {
    padding: 10px 0;
  }
  
  .nav-links {
    gap: 12px;
  }
  
  .nav-link {
    padding: 6px 10px;
    font-size: 13px;
  }
  
  .subcategories-dropdown {
    min-width: 280px;
    margin-top: 4px;
  }
  
  .subcategories-content {
    grid-template-columns: 1fr;
    max-height: 200px;
  }
  
  .subcategory-link {
    padding: 8px 12px;
    font-size: 12px;
  }
  
  .mega-content {
    grid-template-columns: 1fr;
    min-height: 300px;
  }
  
  .mega-main-categories {
    border-radius: 16px 16px 0 0;
    border-right: none;
    border-bottom: 1px solid #e0e0e0;
  }
  
  .mega-subcategories-content {
    grid-template-columns: 1fr;
  }
}

/* Dark mode support */
@media (prefers-color-scheme: dark) {
  .app-header {
    background: #1a1a1a;
  }
  
  .top-bar {
    background: linear-gradient(135deg, #4c63d2 0%, #5a4fcf 100%);
  }
  
  .nav-bar {
    background: #F5F5F5;
  }
  
  .brand-arabic, .brand-english {
    color: #fff;
  }
  
  
  .search-input {
    color: #fff;
  }
  
  .search-input::placeholder {
    color: #999;
  }
  
  .lang-btn, .profile-btn, .login-btn, .action-btn {
    background: #E1EDFF;
    color: #F58040;
  }
  
  
  .nav-link {
    color: #000000;
  }
  
  .subcategories-dropdown {
    background: #2a2a2a;
    border-color: #444;
  }
  
  .subcategory-link {
    color: #fff;
    border-bottom-color: #444;
  }
  
  .subcategory-link:hover {
    background: rgba(102, 126, 234, 0.2);
    color: #E1EDFF;
  }
  
  .mega-main-categories {
    background: #F58040;
    border-right-color: #444;
  }
  
  .mega-title {
    color: #fff;
  }
  
  .mega-title:hover {
    background: rgba(102, 126, 234, 0.2);
    color: #E1EDFF;
  }
  
  .mega-subcategory-item {
    color: #000000;
    border-bottom-color: #444;
  }
  
  .mega-subcategory-item:hover {
    background: rgba(102, 126, 234, 0.2);
    color: #E1EDFF;
  }
  
  .categories-btn {
    background: #F58040;
    border-color: #444;
    color: #fff;
  }
}

/* Mobile Menu Styles */
.mobile-menu-overlay {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.6);
  backdrop-filter: blur(8px);
  z-index: 9999;
  display: flex;
  align-items: flex-start;
  justify-content: flex-end;
  padding: 0;
}

.mobile-menu {
  background: linear-gradient(135deg, #000000 0%, #000000 100%);
  width: 100%;
  height: 100vh;
  max-width: 100vw;
  max-height: 100vh;
  overflow: hidden;
  animation: slideInFull 0.4s cubic-bezier(0.25, 0.46, 0.45, 0.94);
  position: relative;
}

.mobile-menu::before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: 
    radial-gradient(circle at 20% 80%, rgba(120, 119, 198, 0.3) 0%, transparent 50%),
    radial-gradient(circle at 80% 20%, rgba(255, 119, 198, 0.3) 0%, transparent 50%),
    radial-gradient(circle at 40% 40%, rgba(120, 219, 255, 0.2) 0%, transparent 50%);
  z-index: 1;
}

.mobile-menu::after {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><defs><pattern id="grain" width="100" height="100" patternUnits="userSpaceOnUse"><circle cx="25" cy="25" r="1" fill="rgba(255,255,255,0.1)"/><circle cx="75" cy="75" r="1" fill="rgba(255,255,255,0.1)"/><circle cx="50" cy="10" r="0.5" fill="rgba(255,255,255,0.05)"/><circle cx="10" cy="60" r="0.5" fill="rgba(255,255,255,0.05)"/><circle cx="90" cy="40" r="0.5" fill="rgba(255,255,255,0.05)"/></pattern></defs><rect width="100" height="100" fill="url(%23grain)"/></svg>');
  opacity: 0.3;
  z-index: 2;
}

@keyframes slideInFull {
  from {
    opacity: 0;
    transform: translateX(100%);
  }
  to {
    opacity: 1;
    transform: translateX(0);
  }
}

.mobile-menu-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 24px 20px;
  background: rgba(255, 255, 255, 0.1);
  backdrop-filter: blur(20px);
  border-bottom: 1px solid rgba(255, 255, 255, 0.2);
  color: white;
  position: relative;
  z-index: 10;
}

.mobile-menu-header::before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: linear-gradient(135deg, rgba(255, 255, 255, 0.1) 0%, rgba(255, 255, 255, 0.05) 100%);
  z-index: -1;
}

.mobile-menu-header h3 {
  margin: 0;
  font-size: 20px;
  font-weight: 700;
  text-shadow: 0 2px 4px rgba(0, 0, 0, 0.3);
}

.mobile-menu-header .close-btn {
  background: rgba(255, 255, 255, 0.2);
  border: 1px solid rgba(255, 255, 255, 0.3);
  color: white;
  cursor: pointer;
  padding: 12px;
  border-radius: 12px;
  transition: all 0.3s ease;
  backdrop-filter: blur(10px);
}

.mobile-menu-header .close-btn:hover {
  background: rgba(255, 255, 255, 0.3);
  transform: scale(1.05);
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
}

.mobile-menu-content {
  padding: 24px 20px;
  max-height: calc(100vh - 100px);
  overflow-y: auto;
  position: relative;
  z-index: 5;
  scrollbar-width: thin;
  scrollbar-color: rgba(255, 255, 255, 0.3) transparent;
}

.mobile-menu-content::-webkit-scrollbar {
  width: 6px;
}

.mobile-menu-content::-webkit-scrollbar-track {
  background: transparent;
}

.mobile-menu-content::-webkit-scrollbar-thumb {
  background: rgba(255, 255, 255, 0.3);
  border-radius: 3px;
}

.mobile-menu-content::-webkit-scrollbar-thumb:hover {
  background: rgba(255, 255, 255, 0.5);
}

.mobile-menu-content::before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: linear-gradient(135deg, rgba(255, 255, 255, 0.1) 0%, rgba(255, 255, 255, 0.05) 100%);
  z-index: -1;
}

.mobile-menu-section {
  margin-bottom: 32px;
  background: rgba(255, 255, 255, 0.1);
  border-radius: 16px;
  padding: 20px;
  backdrop-filter: blur(20px);
  border: 1px solid rgba(255, 255, 255, 0.2);
  box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
}

.mobile-menu-section h4 {
  margin: 0 0 16px 0;
  font-size: 18px;
  font-weight: 700;
  color: white;
  padding-bottom: 12px;
  border-bottom: 2px solid rgba(255, 255, 255, 0.3);
  text-shadow: 0 2px 4px rgba(0, 0, 0, 0.3);
  position: relative;
}

.mobile-menu-section h4::after {
  content: '';
  position: absolute;
  bottom: -2px;
  left: 0;
  width: 40px;
  height: 2px;
  background: linear-gradient(90deg, #fff, transparent);
}

.mobile-menu-links {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.mobile-menu-link {
  display: block;
  padding: 16px 20px;
  color: rgba(255, 255, 255, 0.9);
  text-decoration: none;
  border-radius: 12px;
  transition: all 0.3s cubic-bezier(0.25, 0.46, 0.45, 0.94);
  font-size: 16px;
  font-weight: 600;
  border: 1px solid rgba(255, 255, 255, 0.2);
  background: rgba(255, 255, 255, 0.1);
  width: 100%;
  text-align: right;
  cursor: pointer;
  backdrop-filter: blur(10px);
  position: relative;
  overflow: hidden;
}

.mobile-menu-link::before {
  content: '';
  position: absolute;
  top: 0;
  left: -100%;
  width: 100%;
  height: 100%;
  background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
  transition: left 0.5s ease;
}

.mobile-menu-link:hover::before {
  left: 100%;
}

.mobile-menu-link:hover {
  background: rgba(255, 255, 255, 0.2);
  color: white;
  transform: translateX(-8px) scale(1.02);
  box-shadow: 0 8px 25px rgba(0, 0, 0, 0.2);
  border-color: rgba(255, 255, 255, 0.4);
}

.mobile-menu-link.logout-btn {
  color: #ff6b6b;
  border: 1px solid rgba(255, 107, 107, 0.3);
  background: rgba(255, 107, 107, 0.1);
}

.mobile-menu-link.logout-btn:hover {
  background: rgba(255, 107, 107, 0.2);
  color: #ff5252;
  border-color: rgba(255, 107, 107, 0.5);
  box-shadow: 0 8px 25px rgba(255, 107, 107, 0.3);
}

/* Global Loading Overlay */
.global-loading-overlay {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.8);
  backdrop-filter: blur(10px);
  z-index: 10000;
  display: flex;
  align-items: center;
  justify-content: center;
  animation: fadeIn 0.3s ease-out;
}

.global-loading-container {
  background: linear-gradient(135deg, #ffffff 0%, #f8f9ff 100%);
  border-radius: 20px;
  padding: 40px;
  text-align: center;
  box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
  border: 1px solid rgba(255, 255, 255, 0.2);
  min-width: 300px;
  position: relative;
  overflow: hidden;
}

.global-loading-container::before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: linear-gradient(135deg, rgba(245, 128, 64, 0.1) 0%, rgba(102, 126, 234, 0.1) 100%);
  z-index: -1;
}

.global-loading-spinner {
  position: relative;
  width: 80px;
  height: 80px;
  margin: 0 auto 24px;
}

.spinner-ring {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  border: 4px solid transparent;
  border-radius: 50%;
  animation: spin 1.5s linear infinite;
}

.spinner-ring:nth-child(1) {
  border-top-color: #F58040;
  animation-delay: 0s;
}

.spinner-ring:nth-child(2) {
  border-right-color: #667eea;
  animation-delay: 0.5s;
}

.spinner-ring:nth-child(3) {
  border-bottom-color: #764ba2;
  animation-delay: 1s;
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}

.global-loading-progress {
  width: 100%;
  height: 6px;
  background: #f0f0f0;
  border-radius: 3px;
  overflow: hidden;
  margin-bottom: 20px;
  position: relative;
}

.global-loading-progress .progress-bar {
  height: 100%;
  background: linear-gradient(90deg, #F58040, #667eea, #764ba2);
  border-radius: 3px;
  transition: width 0.3s ease;
  position: relative;
}

.global-loading-progress .progress-bar::after {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.6), transparent);
  animation: shimmer 1.5s infinite;
}

@keyframes shimmer {
  0% { transform: translateX(-100%); }
  100% { transform: translateX(100%); }
}

.global-loading-message {
  font-size: 18px;
  font-weight: 600;
  color: #333;
  margin-bottom: 16px;
  text-shadow: 0 1px 2px rgba(0, 0, 0, 0.1);
}

.global-loading-dots {
  display: flex;
  justify-content: center;
  gap: 4px;
}

.global-loading-dots span {
  width: 8px;
  height: 8px;
  background: #F58040;
  border-radius: 50%;
  animation: bounce 1.4s ease-in-out infinite both;
}

.global-loading-dots span:nth-child(1) {
  animation-delay: -0.32s;
}

.global-loading-dots span:nth-child(2) {
  animation-delay: -0.16s;
}

.global-loading-dots span:nth-child(3) {
  animation-delay: 0s;
}

@keyframes bounce {
  0%, 80%, 100% {
    transform: scale(0);
  }
  40% {
    transform: scale(1);
  }
}

@keyframes fadeIn {
  from {
    opacity: 0;
  }
  to {
    opacity: 1;
  }
}

/* Hide mobile menu button on desktop */
@media (min-width: 769px) {
  
  .mobile-menu-btn {
    display: none;
  }
}
</style>
