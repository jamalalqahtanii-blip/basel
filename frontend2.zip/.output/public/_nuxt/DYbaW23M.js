const a=()=>({legacy:!1,fallbackLocale:"ar",globalInjection:!0,warnHtmlMessage:!1,silentTranslationWarn:!0,silentFallbackWarn:!0});export{a as default};
