export default defineNuxtPlugin(() => {
  // Placeholder for auth headers, interceptors, etc.
})
