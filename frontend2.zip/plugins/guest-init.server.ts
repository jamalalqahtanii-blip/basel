// Replaced by plugins/00-guest-init.server.ts for deterministic order.
export default defineNuxtPlugin(() => {})
