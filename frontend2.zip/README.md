# 6valley Nuxt Frontend

Dev server:

1. Set API base (optional):
   - Default: http://localhost/api
   - Or set env `NUXT_PUBLIC_API_BASE`.
2. Install deps and run:

```bash
npm install
npm run dev
```

Open http://localhost:3000